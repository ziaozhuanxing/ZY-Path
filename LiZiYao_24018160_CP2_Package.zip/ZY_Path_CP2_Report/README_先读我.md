# ZY-Path CP2 论文交付包

主文件是 LiZiYao_24018160_CP2_Thesis.docx；同名 PDF 为已检查的 89 页审阅版。论文包含你要求的前置页、五章及参考文献、Appendix A–E，18 个图号（7 处明确预留真实证据）、20 张编号表与四类 UML。字体/纸张/页边距沿用 CP1 的主要设置，并保留原封面学校标识及身份信息。

请先阅读《CP1到CP2修订说明.md》和《补图与待补证据清单.md》。没有实际数据的 UAT、独立模型评价、Windows 实机证据和封面学期/日期均明确待补，没有编造。正文保留完整测试 355 passed / 1 failed / 1 collection error。已取得的开发界面截图明确标为 Linux/Qt 或模拟数据，不冒充真实模型效果。

UAT_Questionnaire.docx/PDF 是英文问卷与观察材料；UAT_Data_and_Scoring.xlsx 是空白录入/计分模板。Excel 的独立校验数据没有放入交付的参与者表。Requirements_Traceability.csv、Windows_Acceptance_Record.csv 等可用于补录证据。Source/ 包含完整英文文本、图源及可编辑 SVG；Evidence/ 保留测试日志、哈希与文档检查记录。

修改 Word 后请 Ctrl+A → F9 刷新域与整个目录，并检查增删图表后的编号。所有待填项完成、真实证据/引用及学校模板核对后再作为最终提交稿。论文编制未更改、提交或推送软件代码。
