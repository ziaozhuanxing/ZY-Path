# Editable source

Thesis.md is the expanded English text and tables. assets/ contains the diagrams and explicitly labelled development captures. Author-created SVG diagrams preserve editable text; the class diagram also includes Graphviz DOT. create_figures.py regenerates author-created figures with Python/Matplotlib and Graphviz installed; existing UI captures are retained when the original temporary capture paths are unavailable. The Word report is the primary editable submission document. Its page references should be refreshed after edits.
