"""Author-created figures, plus explicitly labelled existing Qt development captures."""
from pathlib import Path
import shutil
import subprocess
import textwrap
import os
os.environ.setdefault('MPLCONFIGDIR','/tmp/zy-thesis-mpl')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Ellipse, FancyBboxPatch, Circle, Polygon

ROOT=Path(__file__).parent
A=ROOT/'assets'; A.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'savefig.facecolor':'white','svg.fonttype':'none'})
NAVY='#243d57'; BLUE='#dce9f5'; GREY='#edf1f4'; ORANGE='#f7ebd4'

def graph(name,body,rank='TB'):
    src=f'''digraph G {{ graph [rankdir={rank}, bgcolor="white", pad="0.2", nodesep="0.35", ranksep="0.45", dpi=220];
    node [shape=box, style="rounded,filled", fillcolor="#edf3f8", color="#536b82", fontname="DejaVu Sans", fontsize=11, margin="0.14,0.10"];
    edge [color="#536b82", fontname="DejaVu Sans", fontsize=9]; {body} }}'''
    (A/(name+'.dot')).write_text(src)
    for fmt in ('png','svg'):
        subprocess.run(['dot',f'-T{fmt}',str(A/(name+'.dot')),'-o',str(A/(name+'.'+fmt))],check=True)

graph('architecture','''
u [label="Educational / research user", fillcolor="#e7e7e7"];
subgraph cluster_ui { label="Presentation and orchestration · ui/"; color="#a7bccd";
mw [label="MainWindow\nCaptured parameters · worker lifecycle\nresult saving · history restoration"];
panels [label="InferencePanel · HistoryPanel · ActionPanel\nClassificationResult · SegmentationResult\nSettingsDialog · linked image viewers"];
mw -> panels [dir=both,label="signals / state"]; }
subgraph cluster_core { label="Inference · core/"; color="#a7bccd";
load [label="ModelLoader\nformat / metadata / task validation"];
engine [label="InferenceEngine (QThread)\npreprocess · explicit task/mode\nclassification crops OR segmentation fusion"];
load -> engine; }
subgraph cluster_data { label="Persistence and export · data/"; color="#a7bccd";
db [label="DatabaseManager\nSQLite records + analysis JSON"];
files [label="ExportManager + artifact coordinator\nPNG · maps · JSON · PDF"];
}
settings [label="QSettings\nPreferences ≠ historical parameters",fillcolor="#f7ebd4"];
u -> mw; mw -> load [label="validate"]; mw -> engine [label="start / cancel"];
engine -> mw [label="progress / result / error",style=dashed];
mw -> db; mw -> files; mw -> settings [dir=both];
''')

graph('class_diagram',r'''
node [shape=record,style=filled,fillcolor="#f7f9fb",fontsize=10];
mw [label="{MainWindow|_start_inference()\l}"];
ip [label="{InferencePanel|classification_mode()\l}"];
rp [label="{ResultPanel|show_segmentation()\l}"];
hp [label="{HistoryPanel|set_records()\lselected_record_id()\l}"];
engine [label="{InferenceEngine|run_pipeline()\lcancel()\l}"];
qthread [label="{QThread}",fillcolor="#e8edf2"];
loader [label="{ModelLoader|validate()\lforward()\l}"];
prep [label="{Preprocessor|transform()\l}"];
parse [label="{OutputParser|extract_logits()\l}"];
db [label="{DatabaseManager|insert_record()\lsearch()\l}"];
exporter [label="{ExportManager|export_pdf()\l}"];
classification [label="{ClassificationResult|show_result()\l}"];
segmentation [label="{SegmentationResult|show_result()\l}"];
compare [label="{ImageComparison|set_images()\l}"];
zoom [label="{ZoomableImageView|set_tile_grid()\lfit_to_view()\l}"];
{rank=same;ip;rp;hp;} {rank=same;loader;prep;parse;} {rank=same;db;exporter;}
mw -> ip [arrowtail=diamond,dir=back];mw -> rp [arrowtail=diamond,dir=back];mw -> hp [arrowtail=diamond,dir=back];
mw -> engine [style=dashed,label="starts / observes"];mw -> db [style=dashed];mw -> exporter [style=dashed];
engine -> loader [style=dashed];engine -> prep [style=dashed];engine -> parse [style=dashed];
engine -> qthread [arrowhead=empty,label="inherits"];
rp -> classification [arrowtail=diamond,dir=back];rp -> segmentation [arrowtail=diamond,dir=back];classification -> compare [arrowtail=diamond,dir=back];segmentation -> compare [arrowtail=diamond,dir=back];compare -> zoom [arrowtail=diamond,dir=back,label="two views"];
''')

graph('activity','''
start [shape=circle,label="",width=0.18,fillcolor="#243d57"];
select [label="Select trusted model, raster image, task\nand explicit classification mode"];
valid [shape=diamond,label="Compatible model\nand valid inputs?",fillcolor="#f7ebd4"];
choice [shape=diamond,label="Selected pathway",fillcolor="#f7ebd4"];
single [label="Single image\nRGB → selected profile/backend\nwhole image → classifier"];
tiles [label="Tiled classification\nreal source crops → same classifier\nactual crop areas → map / statistics"];
seg [label="Segmentation\nindependent preprocessing / labels\nUPerNet fusion OR compatible path"];
cancel [shape=diamond,label="Cancel requested\nat safe checkpoint?",fillcolor="#f7ebd4"];
stop [label="Acknowledge cancellation\nno partial completed history\npreserve previous result"];
present [label="Render completed result\nsource-aligned views and legend"];
save [shape=diamond,label="Artifacts saved\nsuccessfully?",fillcolor="#f7ebd4"];
record [label="Insert completed record\nactual model / task / mode / parameters"];
error [label="Report actionable error\ndo not invent a substitute prediction",fillcolor="#f5e4df"];
end [shape=doublecircle,label="",width=0.18,fillcolor="#243d57"];
start -> select -> valid;valid -> choice [label="yes"];valid -> error [label="no"];
choice -> single [label="single"];choice -> tiles [label="tiled"];choice -> seg [label="segmentation"];
single -> cancel;tiles -> cancel;seg -> cancel;cancel -> stop [label="yes"];cancel -> present [label="no"];
present -> save;save -> record [label="yes"];save -> error [label="no"];
record -> end;stop -> end;error -> end;
''')

def save(fig,name):
    fig.savefig(A/(name+'.png'),dpi=220,bbox_inches='tight',pad_inches=.12)
    fig.savefig(A/(name+'.svg'),bbox_inches='tight',pad_inches=.12)
    plt.close(fig)

fig,ax=plt.subplots(figsize=(9,4.7));ax.set_xlim(0,10);ax.set_ylim(0,5);ax.axis('off')
labels=[('Whole-image classification','One resized image\n→ one probability vector','One label / chart'),
        ('Tiled classification','Separate source crops\n→ one vector per crop','Class-filled rectangles\nEstimated area coverage'),
        ('Semantic segmentation','Spatial model output\n→ restored pixel labels','Predicted pixel map\nPixel-class coverage')]
for x,(title,mid,bottom) in zip([1.65,5,8.35],labels):
    ax.add_patch(FancyBboxPatch((x-1.5,.45),3,4,boxstyle='round,pad=.03',edgecolor=NAVY,facecolor=GREY))
    ax.text(x,4.05,title,ha='center',weight='bold',fontsize=10)
    ax.text(x,2.8,mid,ha='center',va='center',linespacing=1.6)
    ax.annotate('',(x,1.8),(x,2.2),arrowprops={'arrowstyle':'->','color':NAVY})
    ax.text(x,1.2,bottom,ha='center',va='center',linespacing=1.6)
ax.text(5,.05,'Same source image does not imply the same unit of prediction or the same meaning of coverage.',ha='center',fontsize=9)
save(fig,'spatial_semantics')

fig,ax=plt.subplots(figsize=(10,6));ax.set_xlim(0,10);ax.set_ylim(0,6);ax.axis('off')
def box(x,y,w,h,title,body,color=GREY):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.02',facecolor=color,edgecolor=NAVY))
    ax.text(x+.14,y+h-.25,title,weight='bold',va='top',fontsize=10)
    ax.text(x+.14,y+h-.65,body,va='top',fontsize=9,linespacing=1.7)
box(.05,5.2,9.9,.65,'ZY-Path · title / Settings','',BLUE)
box(.05,.25,2.1,4.75,'INPUT','Built-in / local model\nValidation status\nImage and thumbnail\nTask\nSingle / Tiled mode\nSource tile summary\nRun / Cancel')
box(2.32,1.6,5.25,3.4,'INFERENCE / HISTORY','Overlay / map / original\nOpacity · grid · compare · link\nSource-aligned image viewer\nPaired views when requested',BLUE)
box(2.32,.25,5.25,1.2,'STATISTICS','Coverage cards · optional tile/class details')
box(7.75,.25,2.2,4.75,'ACTIONS','Export PNG / PDF\nRecorded model\nImage · time · ID\nRe-run stored record')
ax.text(5,.03,'Draggable dividers · scrollable panels · narrow/wide adaptation · recorded result ≠ pending selection',ha='center',fontsize=8)
save(fig,'wireframe')

fig,ax=plt.subplots(figsize=(7.1,8.5));ax.set_xlim(-2,10);ax.set_ylim(-.5,11);ax.axis('off')
ax.add_patch(Rectangle((0,0),9.7,10.8,fill=False,edgecolor=NAVY,lw=1.5));ax.text(4.85,10.45,'ZY-Path local application',ha='center',weight='bold')
ax.add_patch(Circle((-1.1,5.5),.24,fill=False,color=NAVY));ax.plot([-1.1,-1.1],[5.26,4.55],color=NAVY);ax.plot([-1.6,-.6],[5,5],color=NAVY);ax.plot([-1.1,-1.5],[4.55,4.1],color=NAVY);ax.plot([-1.1,-.7],[4.55,4.1],color=NAVY);ax.text(-1.1,3.7,'Research /\neducation user',ha='center',fontsize=9)
cases=[(2.4,9.3,'Select model / image'),(2.4,7.6,'Run classification'),(2.4,5.9,'Run segmentation'),(2.4,4.2,'Inspect results'),(2.4,2.5,'Restore / rerun history'),(2.4,.8,'Export / manage records'),(7.2,9.3,'Validate model'),(7.2,7.6,'Tiled analysis'),(7.2,5.9,'Cancel active run'),(7.2,4.2,'Compare / linked views'),(7.2,2.5,'Search / filter'),(7.2,.8,'Configure defaults')]
for x,y,s in cases:
    ax.add_patch(Ellipse((x,y),3.6,1.05,facecolor=BLUE,edgecolor=NAVY));ax.text(x,y,'\n'.join(textwrap.wrap(s,23)),ha='center',va='center',fontsize=9)
for x,y,s in cases[:6]:ax.plot([-.65,.6],[4.85,y],color='#8696a5',lw=.8)
for a,b,label in [(0,6,'«include»'),(7,1,'«extend»'),(9,3,'«extend»'),(10,4,'«extend»')]:
    x1,y1,_=cases[a];x2,y2,_=cases[b]
    ax.annotate('',(x2-1.8 if x2>x1 else x2+1.8,y2),(x1+1.8 if x2>x1 else x1-1.8,y1),arrowprops={'arrowstyle':'->','linestyle':'--','color':NAVY})
    ax.text((x1+x2)/2,(y1+y2)/2+.16,label,ha='center',fontsize=8)
ax.text(7.2,6.62,'Cancellation is available while a run is active.',ha='center',fontsize=7.5)
save(fig,'use_case')

fig,ax=plt.subplots(figsize=(11,8.2));ax.set_xlim(-.6,11);ax.set_ylim(0,11);ax.axis('off')
xs=[.2,2.2,4.2,6.2,8.2,10.2];names=['User','MainWindow','InferenceEngine\n(QThread)','Model pipeline','Artifact files','DatabaseManager']
for x,n in zip(xs,names):
    ax.add_patch(Rectangle((x-.7,10.2),1.4,.65,facecolor=BLUE,edgecolor=NAVY));ax.text(x,10.52,n,ha='center',va='center',fontsize=8.5)
    ax.plot([x,x],[.5,10.2],color='#a2acb8',linestyle='--',lw=.9)
messages=[(0,1,'Run with selected parameters',9.6,False),(1,2,'start() / captured task and mode',8.95,False),
 (2,3,'load/validate → preprocess → forward',8.3,False),(3,2,'parsed output + analysis metadata',7.65,True),
 (2,1,'progress/status signals (during work)',7.0,True),(2,1,'result_ready (only if not cancelled)',6.35,True),
 (1,4,'save result/maps/analysis JSON',5.55,False),(4,1,'saved artifact paths',4.9,True),(1,5,'insert completed record + metadata',4.25,False),
 (5,1,'new record ID',3.6,True),(1,0,'completed view/history/export actions',2.95,True)]
for i,j,label,y,dash in messages:
    ax.annotate('',(xs[j],y),(xs[i],y),arrowprops={'arrowstyle':'->' if dash else '-|>','linestyle':'--' if dash else '-','color':NAVY,'lw':1.1})
    ax.text((xs[i]+xs[j])/2,y+.13,label,ha='center',fontsize=8.2,bbox={'facecolor':'white','edgecolor':'none','pad':1})
ax.add_patch(Rectangle((-.5,.5),11.3,1.65,facecolor=ORANGE,edgecolor=NAVY))
ax.text(-.3,1.82,'Alternative: cancel / error',weight='bold',fontsize=9)
ax.text(-.3,1.28,'Cancel request sets an event; the worker acknowledges at a safe checkpoint.\nNo partial completed record is created. Saving failure is reported and is not successful persistence.',fontsize=9,va='center',linespacing=1.8)
save(fig,'sequence')

# Portrait versions keep labels legible at thesis page width.
fig,ax=plt.subplots(figsize=(6.7,7.4));ax.set_xlim(0,7);ax.set_ylim(0,8);ax.axis('off')
def block(x,y,w,h,title,body,fill=BLUE):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.03',facecolor=fill,edgecolor=NAVY))
    ax.text(x+w/2,y+h-.2,title,ha='center',va='top',weight='bold',fontsize=11)
    ax.text(x+w/2,y+h/2-.05,body,ha='center',va='center',fontsize=9.5,linespacing=1.7)
block(.3,6.65,6.4,.9,'User','Educational / research workflow',GREY)
block(.3,4.5,6.4,1.65,'Presentation and orchestration · ui/',
      'MainWindow · input / result / history / action panels\nSettings · shared coordinate viewers\nCaptured parameters · worker signals · result saving')
block(.3,2.45,6.4,1.55,'Inference · core/',
      'ModelLoader → Preprocessor → model → OutputParser\nSingle image / classification crops / segmentation fusion\nInferenceEngine (QThread) · cooperative cancel')
block(.3,.3,3.05,1.55,'Persistence · data/',
      'DatabaseManager\nSQLite + analysis JSON',GREY)
block(3.65,.3,3.05,1.55,'Artifacts and preferences',
      'ExportManager · PNG/PDF/maps\nQSettings (separate defaults)',GREY)
for a,b in [((3.5,6.65),(3.5,6.15)),((3.5,4.5),(3.5,4)),((2,2.45),(1.85,1.85)),((5,2.45),(5.15,1.85))]:
    ax.annotate('',b,a,arrowprops={'arrowstyle':'->','color':NAVY,'lw':1.3})
ax.text(3.5,2.15,'MainWindow coordinates completed results and artifact persistence.',ha='center',fontsize=8.5)
save(fig,'architecture')

fig,ax=plt.subplots(figsize=(6.8,6.3));ax.set_xlim(-.8,6.8);ax.set_ylim(0,10);ax.axis('off')
xs=[0,1.5,3,4.5,6];names=['MainWindow','InferenceEngine\n(QThread)','Model pipeline','Artifact files','DatabaseManager']
for x,n in zip(xs,names):
    ax.add_patch(Rectangle((x-.65,9.15),1.3,.65,facecolor=BLUE,edgecolor=NAVY));ax.text(x,9.48,n,ha='center',va='center',fontsize=8.2)
    ax.plot([x,x],[1.7,9.15],color='#a2acb8',linestyle='--',lw=.9)
msgs=[(0,1,'start() + captured\nparameters',8.6,'call'),(1,2,'validate / preprocess\nforward / parse',7.85,'call'),
      (1,0,'progress / status signals',7.1,'signal'),(2,1,'parsed output',6.45,'return'),
      (1,0,'result_ready (unless cancelled)',5.75,'signal'),(0,3,'render / save completed artifacts',5.05,'call'),
      (3,0,'saved paths',4.35,'return'),(0,4,'insert actual metadata / artifact paths',3.65,'call'),
      (4,0,'new record ID → update history',2.95,'return')]
for i,j,label,y,typ in msgs:
    ax.annotate('',(xs[j],y),(xs[i],y),arrowprops={'arrowstyle':'-|>' if typ=='call' else '->','linestyle':'--' if typ=='return' else '-','color':NAVY,'lw':1.1})
    ax.text((xs[i]+xs[j])/2,y+.1,label,ha='center',fontsize=8.6,linespacing=1.15,bbox={'facecolor':'white','edgecolor':'none','pad':1})
ax.add_patch(Rectangle((-.55,.1),7.1,1.5,facecolor=ORANGE,edgecolor=NAVY))
ax.text(-.35,1.42,'Alternative: cancellation / error',weight='bold',fontsize=9.5,va='top')
ax.text(-.35,1.04,'A cancel event is checked at a safe checkpoint.\nNo partial completed record is inserted.\nSaving failure is reported, not treated as saved history.',fontsize=9.2,va='top',linespacing=1.3)
save(fig,'sequence')

fig,ax=plt.subplots(figsize=(6.8,7.6));ax.set_xlim(0,7.1);ax.set_ylim(-.1,8.6);ax.axis('off')
def process(x,y,w,h,text,diamond=False,fill=BLUE):
    if diamond:
        ax.add_patch(Polygon([(x-w/2,y),(x,y+h/2),(x+w/2,y),(x,y-h/2)],facecolor=ORANGE,edgecolor=NAVY))
    else:
        ax.add_patch(FancyBboxPatch((x-w/2,y-h/2),w,h,boxstyle='round,pad=.03',facecolor=fill,edgecolor=NAVY))
    ax.text(x,y,text,ha='center',va='center',fontsize=9,linespacing=1.25)
def arrow(a,b,label=None):
    ax.annotate('',b,a,arrowprops={'arrowstyle':'->','color':NAVY,'lw':1})
    if label:ax.text((a[0]+b[0])/2+.05,(a[1]+b[1])/2+.08,label,fontsize=8,color=NAVY)
ax.add_patch(Circle((3.4,8.35),.08,facecolor=NAVY));arrow((3.4,8.25),(3.4,7.97))
process(3.4,7.65,4.5,.6,'Select model, image, task and explicit mode')
process(3.4,6.65,2.5,.7,'Valid model\nand inputs?',True)
process(5.95,6.65,1.7,.7,'Report error\nno new record',fill=GREY)
arrow((3.4,7.35),(3.4,7.0));arrow((4.65,6.65),(5.1,6.65),'no')
process(3.4,5.65,2.4,.65,'Selected pathway',True);arrow((3.4,6.3),(3.4,5.98),'yes')
for x,title in [(1.1,'Single image\ncomplete image\n→ one vector'),(3.4,'Classification tiles\nactual source crops\n→ vectors / areas'),(5.8,'Segmentation\nindependent labels\n→ restored mask')]:
    process(x,4.55,2.0,.95,title)
    arrow((3.4,5.32),(x,5.03))
    arrow((x,4.075),(3.4,3.75))
process(3.4,3.4,2.6,.7,'Cancel requested\nat checkpoint?',True)
process(5.95,3.4,1.7,.8,'Acknowledge\ncancellation\nretain previous',fill=GREY)
arrow((4.7,3.4),(5.1,3.4),'yes')
process(3.4,2.45,3.6,.6,'Render result and save artifacts');arrow((3.4,3.05),(3.4,2.75),'no')
process(3.4,1.5,2.6,.7,'Saved successfully?',True);arrow((3.4,2.15),(3.4,1.85))
process(5.95,1.5,1.7,.7,'Report save error\nno new record',fill=GREY);arrow((4.7,1.5),(5.1,1.5),'no')
process(3.4,.6,3.7,.55,'Insert completed record / metadata');arrow((3.4,1.15),(3.4,.88),'yes')
ax.add_patch(Circle((3.4,.04),.09,facecolor='white',edgecolor=NAVY));ax.add_patch(Circle((3.4,.04),.055,facecolor=NAVY));arrow((3.4,.32),(3.4,.14))
for cy,bottom in ((5.98,6.3),(2.75,3.0),(.92,1.15)):
    ax.add_patch(Circle((5.95,cy),.075,facecolor='white',edgecolor=NAVY))
    ax.add_patch(Circle((5.95,cy),.045,facecolor=NAVY))
    arrow((5.95,bottom),(5.95,cy+.08))
save(fig,'activity')
(A/'architecture.dot').unlink(missing_ok=True)
(A/'activity.dot').unlink(missing_ok=True)

fig,ax=plt.subplots(figsize=(7.1,8.3));ax.set_xlim(-2,9.8);ax.set_ylim(.1,10.7);ax.axis('off')
ax.add_patch(Rectangle((0,.4),9.4,10.0,fill=False,edgecolor=NAVY,lw=1.3))
ax.text(4.7,10.15,'ZY-Path local application',ha='center',weight='bold',fontsize=10.5)
ax.add_patch(Circle((-1.1,5.5),.22,fill=False,color=NAVY))
ax.plot([-1.1,-1.1],[5.28,4.6],color=NAVY);ax.plot([-1.55,-.65],[5.03,5.03],color=NAVY)
ax.plot([-1.1,-1.45],[4.6,4.15],color=NAVY);ax.plot([-1.1,-.75],[4.6,4.15],color=NAVY)
ax.text(-1.1,3.85,'Research /\neducation user',ha='center',va='top',fontsize=8.5)
base=[('Select model / image',9.45),('Run classification',8.25),('Run segmentation',7.05),('Inspect results',5.85),('Restore / rerun history',4.65),('Export / delete records',3.45),('Cancel active run',2.25),('Configure defaults',1.05)]
for title,y in base:
    ax.plot([-.65,1.05],[5.0,y],color='#8a9baa',lw=.8,zorder=0)
    ax.add_patch(Ellipse((2.8,y),3.5,.8,facecolor=BLUE,edgecolor=NAVY))
    ax.text(2.8,y,title,ha='center',va='center',fontsize=9)
for title,y,label,direction in [('Validate model',9.45,'«include»','right'),('Tiled analysis',8.25,'«extend»','left'),('Compare / link views',5.85,'«extend»','left'),('Search / filter',4.65,'«extend»','left')]:
    ax.add_patch(Ellipse((7.1,y),3.5,.8,facecolor=BLUE,edgecolor=NAVY))
    ax.text(7.1,y,title,ha='center',va='center',fontsize=9)
    a,b=((4.55,y),(5.35,y)) if direction=='right' else ((5.35,y),(4.55,y))
    ax.annotate('',b,a,arrowprops={'arrowstyle':'->','linestyle':'--','color':NAVY})
    ax.text(4.95,y+.2,label,ha='center',fontsize=7)
save(fig,'use_case')

fig,ax=plt.subplots(figsize=(9,4.1));ax.axis('off')
lines=['SOURCE: saved full pytest log · revision 1f3e01e',
       'pytest -q --continue-on-collection-errors --tb=short',
       '', '355 PASSED     1 FAILED     1 COLLECTION ERROR',
       '', 'Failure: real classification weight file is absent.',
       'Collection error: expected CRC resume training script is absent.',
       '', 'Related regressions: 83 passed.',
       'Qt scale 1.5 / 2.0: 7 passed per run (overlapping subsets).',
       'Software verification ≠ model accuracy ≠ Windows-native acceptance.']
ax.add_patch(FancyBboxPatch((.01,.01),.98,.98,transform=ax.transAxes,boxstyle='round,pad=.01',facecolor=GREY,edgecolor=NAVY))
ax.text(.035,.94,'\n'.join(lines),transform=ax.transAxes,va='top',fontfamily='DejaVu Sans Mono',fontsize=9.3,linespacing=1.6)
save(fig,'test-summary')

for src,name in [('/tmp/zy-result-controls-review/controls-dark.png','controls-dark.png'),('/tmp/zy-final-polish-review/guide-top.png','guide-top.png'),('/tmp/zy-result-controls-review/calendar-english.png','calendar-english.png')]:
    if Path(src).is_file():shutil.copy2(src,A/name)
print('assets generated',len(list(A.iterdir())))
