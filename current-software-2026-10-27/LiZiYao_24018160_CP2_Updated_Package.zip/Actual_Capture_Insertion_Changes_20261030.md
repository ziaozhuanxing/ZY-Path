# Actual Windows capture insertion — 30 October 2026



Actual observations are distinguished from test-model settings and uncompleted formal acceptance.



## 1. Figure 1.1

Before: Screenshot evidence placeholder.

After: Inserted original authorised image/capture panels; native Word crops identify details without retouching pixels.

Reason: Use the actual uploaded evidence; retain source IDs and distinguish observations from predictive validation.



## 2. Figure 4.1

Before: Screenshot evidence placeholder.

After: Inserted original authorised image/capture panels; native Word crops identify details without retouching pixels.

Reason: Use the actual uploaded evidence; retain source IDs and distinguish observations from predictive validation.



## 3. Figure 4.3

Before: Screenshot evidence placeholder.

After: Inserted original authorised image/capture panels; native Word crops identify details without retouching pixels.

Reason: Use the actual uploaded evidence; retain source IDs and distinguish observations from predictive validation.



## 4. Figure 4.4

Before: Screenshot evidence placeholder.

After: Inserted original authorised image/capture panels; native Word crops identify details without retouching pixels.

Reason: Use the actual uploaded evidence; retain source IDs and distinguish observations from predictive validation.



## 5. Figure 4.5

Before: Screenshot evidence placeholder.

After: Inserted original authorised image/capture panels; native Word crops identify details without retouching pixels.

Reason: Use the actual uploaded evidence; retain source IDs and distinguish observations from predictive validation.



## 6. Figure 4.6

Before: Screenshot evidence placeholder.

After: Inserted original authorised image/capture panels; native Word crops identify details without retouching pixels.

Reason: Use the actual uploaded evidence; retain source IDs and distinguish observations from predictive validation.



## 7. Figure 4.9

Before: Screenshot evidence placeholder.

After: Inserted original authorised image/capture panels; native Word crops identify details without retouching pixels.

Reason: Use the actual uploaded evidence; retain source IDs and distinguish observations from predictive validation.



## 8. Figure 1.1

Before: Figure 1.1. Representative H&E colorectal tissue image (evidence pending; replace this reserved area with the actual authorised capture).

After: Figure 1.1. TUM-labelled H&E patch TUM-TCGA-AAHIDTWA.tif, 224 × 224 pixels. Source: CRC-VAL-HE-7K, identified by the author; dataset DOI 10.5281/zenodo.1214456.

Reason: Replace the pending claim only to the extent supported by the supplied Windows captures and report.



## 9. Figure 4.1

Before: Figure 4.1. Final Windows application overview (evidence pending; replace this reserved area with the actual authorised capture).

After: Figure 4.1. Windows application overview with Single image classification, probability chart and session/export panels. The displayed analysis is record #52. Source: author’s Windows capture.

Reason: Replace the pending claim only to the extent supported by the supplied Windows captures and report.



## 10. Figure 4.3

Before: Figure 4.3. Real-weight single-image and tiled classification evidence (evidence pending; replace this reserved area with the actual authorised capture).

After: Figure 4.3. Windows classification on crop.jpg_original.png: (a) Single image; (b) 49 numbered 512 × 512 source tiles; (c) crop inspection from the separately recorded analysis #48. The application uses raw255 and OpenCV linear resize to 224 × 224. Source: author’s Windows captures.

Reason: Replace the pending claim only to the extent supported by the supplied Windows captures and report.



## 11. Figure 4.4

Before: Figure 4.4. Windows segmentation result and aligned comparison (evidence pending; replace this reserved area with the actual authorised capture).

After: Figure 4.4. Original/segmentation-overlay comparison for a 3552 × 3536 image, with linked Fit views at 15.7%, opacity 30% and all nine pixel-coverage classes. The displayed analysis is record #49 using the supervisor-provided UPerNet model. Source: author’s Windows capture.

Reason: Replace the pending claim only to the extent supported by the supplied Windows captures and report.



## 12. Figure 4.5

Before: Figure 4.5. History and recorded-parameter rerun (evidence pending; replace this reserved area with the actual authorised capture).

After: Figure 4.5. Windows history and parameter isolation: (a) both classification modes; (b) displayed record #73 retains 512 × 512/49 tiles while current preferences show 256 × 256/196 tiles; (c) ordinary Run creates record #77 with 256 × 256/196 tiles. Source: author’s Windows captures.

Reason: Replace the pending claim only to the extent supported by the supplied Windows captures and report.



## 13. Figure 4.6

Before: Figure 4.6. Exported report and companion artifacts (evidence pending; replace this reserved area with the actual authorised capture).

After: Figure 4.6. Actual Standard-quality segmentation PDF, its metadata page and Windows file listing. Analysis record #65 is dated 25 October; the PDF was exported on 30 October 2026. The listed PNG is not included in the uploaded evidence. Source: author’s report and captures.

Reason: Replace the pending claim only to the extent supported by the supplied Windows captures and report.



## 14. Figure 4.9

Before: Figure 4.9. Cancellation and per-task model defaults on Windows (evidence pending; replace this reserved area with the actual authorised capture).

After: Figure 4.9. Windows cancellation and default-model controls: (a) 228/400 processing progress; (b) cancellation acknowledged with completed record #79 retained; (c) configuration using the controlled test model dummy_segmentation.pt; (d) restored built-in default. The transient Cancelling screen was not captured. Source: author’s Windows captures.

Reason: Replace the pending claim only to the extent supported by the supplied Windows captures and report.



## 15. 4.2.1

Before: The Windows session on 19 October 2026 launched the application from its virtual environment and recorded successful loading and validation of crc_dn21_seed42_best.pth as a nine-class DenseNet with output shape (1, 9). This establishes source-based startup and classifier integration for that session. The observed workflow and window states are detailed in Section 4.3.3. Figure 4.1 reserves the corresponding Windows application overview; the authorised screenshot remains to be inserted.

After: The Windows startup record on 19 October 2026 establishes classifier loading and validation. Figure 4.1 now supplies a direct Windows application capture with an actual Single image result, showing the input, probability chart and export/session regions. Its displayed record #52 identifies a NORM-labelled 224 × 224 input and 99.9% model confidence. This is an observed prediction, not an additional accuracy experiment.

Reason: Replace the pending claim only to the extent supported by the supplied Windows captures and report.



## 16. 4.2.2

Before: Figure 4.2 is a retained earlier Qt result-view capture using a deterministic synthetic fixture. It illustrates the grid, paired views and statistics placement. The fixture contains 49 tiles with 47 STR, one NORM and one MUC assignments. These are prescribed test data, not predictions on the coloured source pattern. Current-version real-image inspection remains reserved in Figure 4.3, including tile numbers and original-crop detail.

After: Figure 4.2 is a retained earlier Qt result-view capture using a deterministic synthetic fixture. It illustrates the grid, paired views and statistics placement. The fixture contains 49 tiles with 47 STR, one NORM and one MUC assignments. These are prescribed test data, not predictions on the coloured source pattern. Figure 4.3 provides separate actual-image Windows observations, including tile numbers and original-crop inspection.

Reason: Replace the pending claim only to the extent supported by the supplied Windows captures and report.



## 17. 4.2.2

Before: Figure 4.3 reserves real-weight Windows captures of Single image and Tiled analysis; these pending captures are separate from the synthetic interface example in Figure 4.2.

After: Figure 4.3(a–b) shows Single image and Tiled analysis for the same named 3552 × 3536 raster. The Single image result selects STR with 42.6% confidence. The tiled view reports 40 STR, five MUC, one MUS and three NORM tiles, with estimated area coverage 82.06%, 9.98%, 1.89% and 6.07%, respectively. Its 512-pixel source crops use RGB/raw255 and OpenCV linear resize to 224 × 224. Panel (c), from a separate analysis, identifies tile 31 as NORM at 59.47%, with rectangle [1024, 2048, 1536, 2560]. These observations demonstrate presentation and crop inspection; they do not supply ground-truth tile accuracy.

Reason: Replace the pending claim only to the extent supported by the supplied Windows captures and report.



## 18. 4.2.3

Before: The reference notebook establishes the segmentation architecture, preprocessing, labels and probability-fusion procedure. Controlled software tests cover restored dimensions, class counts and blending behaviour. Segmentation predictive performance is treated separately: annotated-mask metrics were not available for this model, as discussed in Section 4.5.3. Figure 4.4 reserves the real-weight Windows segmentation view and aligned source comparison; the capture is still pending.

After: The reference notebook establishes the segmentation architecture, preprocessing, labels and probability fusion. Figure 4.4 now shows a direct Windows run with the supervisor-provided UPerNet model, aligned source/overlay views and nine-class pixel coverage. The supplied segmentation analysis metadata records imagenet preprocessing, a 1000-pixel source window, stride 512 and network input 224 on CPU. The actual PDF and JSON counts sum to 12,559,872 pixels, equal to 3552 × 3536. The export and screen concern different analysis records; their matching counts are not independent accuracy measurements. Annotated-mask evaluation remains unavailable (Section 4.5.3).

Reason: Replace the pending claim only to the extent supported by the supplied Windows captures and report.



## 19. 4.2.4

Before: Rerun tests demonstrate that the recorded model/task/mode and analysis settings take precedence over current preferences. Restoring a record does not itself create a new prediction. The export workflow uses the displayed completed record's metadata and can retain task-specific maps/JSON together with the presentation. This prevents a newly selected model from being incorrectly attached to an older visible result. Figure 4.6 reserves an exported report and its companion artifacts for inspection; the real-file capture remains pending.

After: Regression tests establish recorded-parameter Re-run separately from ordinary Run. Figure 4.5 supplies Windows observations of both classification modes in History, a 512-pixel displayed record alongside 256-pixel current preferences, and a completed ordinary Run using the current 256-pixel setting. The separate Re-run capture shows 49/49 progress while busy controls remain active; it is retained as progress evidence, not as proof that a new record finished saving. Figure 4.6 shows an actual exported report and file listing.

Reason: Replace the pending claim only to the extent supported by the supplied Windows captures and report.



## 20. 4.2.4 / remaining Re-run capture

Before: [New evidence paragraph]

After: Pending evidence: a completed recorded-parameter Re-run capture after controls unlock, identifying the new record and its retained parameters. The supplied 49/49 progress image alone does not confirm that persistence completed.

Reason: Record an observed result or remaining evidence boundary.



## 21. 4.2.4 / export evidence

Before: [New evidence paragraph]

After: The supplied two-page PDF is 875,021 bytes and identifies Standard quality, software version 1.0, CPU execution, source dimensions and segmentation parameters. It records an analysis timestamp of 25 October 2026 and an export timestamp of 30 October 2026. Its export-time model hash matches the genuine UPerNet resource identity in Appendix E, while the report explicitly states that an export-time hash does not establish the historical inference file. The companion JSON agrees with the PDF’s nine pixel counts. The file listing also shows a PNG, whose source file was not uploaded.

Reason: Record an observed result or remaining evidence boundary.



## 22. 4.2.5

Before: Cancel inference is available during work. Tests cover cancellation at multiple checkpoints and preservation of the previous completed result. The interface waits for the current operation and worker cleanup; it does not advertise instantaneous termination. A final real-model cancellation recording remains useful because the duration of an individual model operation depends on the actual weights, workload and hardware. Figure 4.9 reserves the Windows demonstration of cancellation and task-specific model defaults.

After: Figure 4.9(a–b) documents an actual classification operation at 228/400 processing regions and the subsequent acknowledgement, “Inference cancelled. Previous completed results are unchanged.” Completed record #79 remains displayed. The transient Cancelling state was not captured, and this pair does not by itself audit every history/database entry. Panels (c–d) show default-path configuration with a test model and restoration of the built-in segmentation default. The author identifies dummy_segmentation.pt as a test model; these panels demonstrate settings interaction rather than genuine trained-model predictive performance.

Reason: Replace the pending claim only to the extent supported by the supplied Windows captures and report.



## 23. 4.3.3

Before: [New evidence paragraph]

After: The supplied Windows screenshots add representative actual-image observations of classification, segmentation, linked display, history/default isolation, export and cancellation. They are not a completed W01–W15 acceptance sheet. Their session source commit was not supplied, so they are not attributed to the automated 3a935ef execution. Figure 4.1, Figure 4.3 and Figure 4.4 retain their actual displayed record IDs; the author confirms that these were direct-run captures, not history-restoration demonstrations.

Reason: Record an observed result or remaining evidence boundary.



## 24. 3.6.6 / F06

Before: Current Windows synthetic segmentation geometry/statistics and display cases passed; real-weight demonstration and ground-truth evaluation pending.

After: Current Windows automated segmentation cases passed. Figure 4.4 and the supplied report add actual-image output/coverage observations; ground-truth evaluation and formal manual acceptance remain pending.

Reason: Update the actual available observation without marking formal acceptance as passed.



## 25. 3.6.6 / F12

Before: Current Windows file/report, background export, image-quality and recorded-metadata cases passed; final real-image report screenshots remain to be supplied.

After: Current Windows automated export cases passed. Figure 4.6 and the actual two-page PDF/JSON provide real export evidence; the listed PNG itself was not supplied.

Reason: Update the actual available observation without marking formal acceptance as passed.



## 26. 3.6.6 / F13

Before: Current Windows cooperative-stop, late-result and destruction/callback lifecycle cases passed; real-model manual cancellation record pending.

After: Current Windows automated cancellation/lifecycle cases passed. Figure 4.9 shows a real operation and acknowledged cancellation with the prior displayed result retained; transient Cancelling and full manual protocol evidence are incomplete.

Reason: Update the actual available observation without marking formal acceptance as passed.



## 27. 4.5.1 / O3

Before: Default-Pillow Single image core: 90.68% accuracy / 88.59% macro-F1 on 7,180 native patches. Crop coordinates and parameter isolation have explicit regression assertions; tiled predictive and segmentation evaluation remain pending.

After: Default-Pillow patch evaluation remains 90.68% accuracy / 88.59% macro-F1 on 7,180 patches. Actual Windows captures demonstrate Single image, 49-tile classification and supervisor-model segmentation; tiled accuracy and segmentation ground truth remain unevaluated.

Reason: Update the actual available observation without marking formal acceptance as passed.



## 28. 4.5.1 / O4

Before: Current Windows numbered-tile, original-crop, coordinate/grid and linked-navigation cases passed. User interpretation and real-image manual tasks remain separate evaluations.

After: Current Windows automated inspection cases passed. Actual captures show numbered tiles, a source-crop preview and aligned segmentation comparison. User interpretation and formal acceptance remain separate evaluations.

Reason: Update the actual available observation without marking formal acceptance as passed.



## 29. 4.5.1 / O5

Before: Current Windows background atomic/cancellable PDF, image-quality, file/encoding and recorded-metadata cases passed. Synthetic report-size observations remain distinct from real-image captures.

After: Automated export cases passed; Figure 4.6 and the supplied actual PDF/JSON add real report evidence. The 875,021-byte Standard PDF is one export observation, not a general performance benchmark.

Reason: Update the actual available observation without marking formal acceptance as passed.



## 30. 4.5.1 / O7

Before: Current Windows search, filtering, zero-selection, restore and recorded-rerun cases passed, including preference/record isolation. User efficiency remains unmeasured.

After: Automated retrieval/rerun cases passed. Windows captures show both modes in History, displayed-record/current-preference isolation and a current-setting Run. A completed recorded Re-run capture and user-efficiency data remain pending.

Reason: Update the actual available observation without marking formal acceptance as passed.



## 31. 4.5.3

Before: The 508-case Windows suite verifies the evaluated software revision under the recorded runtime. Formal real-image manual acceptance, authorised current screenshots, participant UAT and representative assistive-technology assessment remain incomplete. These concern user experience and acceptance rather than an outstanding automated regression result.

After: The 508-case Windows suite verifies its source revision under the recorded runtime. Actual Windows captures and a segmentation PDF/JSON now document representative image workflows, including overlays, numbered crop inspection, parameter isolation, export and acknowledged cancellation. A complete source-stamped manual acceptance record, participant UAT and assistive-technology assessment remain incomplete. The transient Cancelling view and a completed recorded Re-run capture are not available; default-path interaction is shown with an explicitly identified test model.

Reason: Replace the pending claim only to the extent supported by the supplied Windows captures and report.



## 32. 5.1

Before: The Windows default-Pillow evaluation produced 6,511 correct labels from 7,180 native-sized test patches: 90.68% accuracy and 88.59% macro-F1. Every predicted label agrees with the recorded reference pipeline, with small probability differences. Software verification remains separate: revision 3a935ef passed all 508 automated cases on Windows, with no failures, errors or skipped cases. Real-image manual acceptance, UAT, performance/deployment measurements and broader predictive claims retain the limits in Section 4.5.3.

After: The Windows default-Pillow evaluation produced 6,511 correct labels from 7,180 native-sized test patches: 90.68% accuracy and 88.59% macro-F1. Every predicted label agrees with the recorded reference pipeline, with small probability differences. Software verification remains separate: revision 3a935ef passed all 508 automated cases on Windows, with no failures, errors or skipped cases. Actual Windows screenshots and report artifacts additionally document representative image workflows. Formal manual acceptance, UAT, performance/deployment measurements and broader predictive claims retain the limits in Section 4.5.3.

Reason: Replace the pending claim only to the extent supported by the supplied Windows captures and report.



## 33. Appendix A.2

Before: Implemented; current Windows automated cases passed; final real-image capture remains pending

After: Actual Windows source/segmentation comparison and numbered-crop captures supplied; complete formal acceptance still pending.

Reason: Update the actual available observation without marking formal acceptance as passed.



## 34. Appendix A.2

Before: Task/material protocol and complete current Windows regression recorded; no actual UAT responses or completed real-image manual sheets supplied

After: Complete current Windows automated regression plus actual image screenshots/PDF/JSON; no UAT responses or completed W01–W15 sheets supplied.

Reason: Update the actual available observation without marking formal acceptance as passed.



## 35. Appendix A.3

Before: The evaluated software source and complete Windows regression are recorded. Before submission, complete authorised screenshots, real-image manual tasks and the UAT protocol, and supply semester/submission date. Preserve the earlier Windows and classifier-evaluation records with their original scope. Execute the performance or deployment protocols when those claims are to be made; otherwise retain their explicit incomplete status.

After: The evaluated software source and complete Windows regression are recorded. Representative screenshot groups and actual PDF/JSON have now been supplied. Before submission, complete the remaining recorded Re-run evidence, source-stamped manual acceptance and UAT, and supply semester/submission date. Preserve the original scope of classifier evaluation and dated Windows evidence. Performance or deployment claims require the corresponding protocols.

Reason: Replace the pending claim only to the extent supported by the supplied Windows captures and report.



## 36. Appendix C.1 / Table C.1 / E24

Before: No actual screenshot/report material indexed.

After: Added actual screenshots, dataset patch, PDF and JSON with bounded evidence scope.

Reason: Keep new evidence distinct from automated execution and unverified source identities.



## 37. Appendix C.1

Before: [New evidence paragraph]

After: The new image collection contains direct-run screenshots with analysis timestamps in October and separate History/default demonstrations. The application commit used for these capture sessions was not provided. Accordingly, the figures identify their displayed records rather than assigning the 3a935ef automated-test identity or deriving capture dates from stored record timestamps. The author identifies the custom-default demonstration file as a test model.

Reason: Record an observed result or remaining evidence boundary.



## 38. Appendix D.2

Before: Figures 1.1 and 4.1, 4.3–4.6 and 4.9 explicitly reserve the required evidence. The accompanying Chinese capture guide gives step-by-step framing and filenames. Figures 4.2, 4.7 and 4.8 are labelled development captures; retain that label or replace them with equivalent current Windows captures and update the caption's environment/source description. Screenshot dates, model identity and software revision must correspond to the actual captured run.

After: Figures 1.1 and 4.1, 4.3–4.6 and 4.9 now contain the supplied dataset image and Windows captures. Figures 4.2, 4.7 and 4.8 retain their explicitly labelled development captures. Remaining screenshot evidence is a completed recorded Re-run; the transient Cancelling view was not captured. The supporting capture index distinguishes image filenames, record timestamps, test-model settings and actual report artifacts. These observations do not prefill formal acceptance cases.

Reason: Replace the pending claim only to the extent supported by the supplied Windows captures and report.



## 39. 1.1

Before: Figure 1.1 is reserved for an authorised H&E example illustrating this tissue context.

After: Figure 1.1 illustrates this tissue context using a TUM-labelled patch from CRC-VAL-HE-7K.

Reason: Refer to the inserted dataset image while preserving existing citation links.



## 40. Abstract

Before: Deploying pathology models through separate scripts makes preprocessing, spatial sampling and previous analysis settings difficult to inspect. This project develops ZY-Path, a local PyQt5 desktop application that connects supported PyTorch CPU inference to explicit Single image and Tiled analysis controls, spatial inspection, recorded history and export, with a separate supervisor-provided segmentation integration. The classifier achieved 90.68% accuracy and 88.59% macro-F1 on 7,180 native 224 × 224 CRC-VAL-HE-7K patches through the application’s default Pillow core, agreeing with every predicted label from the recorded reference pipeline. On 27 October 2026, revision 3a935ef passed all 508 automated tests on native Windows Qt, with no failures, errors or skipped cases. The engineering contribution is a model-aware desktop workflow with explicit crop geometry, independent task semantics and reproducible parameter restoration. The remaining usability, native-acceptance, performance and deployment work is defined in Section 4.5.3.

After: Deploying pathology models through separate scripts makes preprocessing, spatial sampling and previous analysis settings difficult to inspect. This project develops ZY-Path, a local PyQt5 desktop application that connects supported PyTorch CPU inference to explicit Single image and Tiled analysis controls, spatial inspection, recorded history and export, with a separate supervisor-provided segmentation integration. The classifier achieved 90.68% accuracy and 88.59% macro-F1 on 7,180 native 224 × 224 CRC-VAL-HE-7K patches through the application’s default Pillow core, agreeing with every predicted label from the recorded reference pipeline. On 27 October 2026, revision 3a935ef passed all 508 automated tests on native Windows Qt, with no failures, errors or skipped cases. The engineering contribution is a model-aware desktop workflow with explicit crop geometry, independent task semantics and reproducible parameter restoration. Separately, Windows captures and an actual PDF/JSON export document representative image workflows and acknowledged cancellation. The remaining usability, native-acceptance, performance and deployment work is defined in Section 4.5.3.

Reason: Add the supplied visual/artifact observations without changing evaluation metrics or formal acceptance status.

