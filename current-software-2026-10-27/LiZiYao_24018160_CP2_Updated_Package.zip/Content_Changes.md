# Evidence consolidation — 30 October 2026



Content edits only; existing styles, diagrams, plain tables, references and verified test/model results are retained.



## 1. 3.3.3

Before: My supervisor provided the segmentation model and the reference notebook predict-upernet-tme-tissue-overlap.ipynb; I did not participate in segmentation training. The notebook constructs a nine-label UPerNet using the openmmlab/upernet-swin-base configuration. Its large-image example uses source tile=1000 and stride=512, which are the application defaults; network input is 224 × 224. The application runs the path on CPU with batch size one, while the notebook example requests CUDA and its function defaults to batch size eight.

After: My supervisor provided the segmentation model and the reference notebook predict-upernet-tme-tissue-overlap.ipynb; I did not participate in segmentation training. The model was trained on breast-cancer data, and the 3552 × 3536 demonstration image also comes from a breast-cancer dataset. The specific dataset names and the image resolution in micrometres per pixel are unavailable. The notebook constructs a nine-label UPerNet using the openmmlab/upernet-swin-base configuration. Its large-image example uses source tile=1000 and stride=512, which are the application defaults; network input is 224 × 224. The application runs on CPU with batch size one, whereas the notebook example requests CUDA and defaults to batch size eight.

Reason: Record the confirmed breast-cancer domains without inventing a named dataset, training involvement or MPP.



## 2. 4.2.2

Before: The 3552 × 3536 geometry example produces 49 crops at a 512 × 512 setting, with smaller right and bottom edges. Controlled tests verify unique source crops, RGB/raw255 preparation, class order, edge handling and area conservation. The tissue accuracy of a tiled map requires a separately defined ground-truth and scale protocol; the patch-classification results in Section 4.2.6 do not measure that map.

After: The 3552 × 3536 breast-cancer raster in Figure 4.3 produces 49 crops at a 512 × 512 setting, with smaller right and bottom edges. Controlled tests verify unique source crops, RGB/raw255 preparation, class order, edge handling and area conservation. Applying the CRC-trained classifier to this image demonstrates the interface and sampling workflow; breast-tissue classification accuracy has not been evaluated. Its unknown physical resolution also prevents training-scale matching. The CRC patch results in Section 4.2.6 do not measure this tiled map.

Reason: Distinguish cross-domain workflow demonstration from the patient-independent CRC patch evaluation.



## 3. Figure 4.3 caption

Before: Figure 4.3. Windows classification on crop.jpg_original.png: (a) Single image; (b) 49 numbered 512 × 512 source tiles; (c) crop inspection from the separately recorded analysis #48. The application uses raw255 and OpenCV linear resize to 224 × 224. Source: author’s Windows captures.

After: Figure 4.3. Windows classification workflow on a supervisor-provided breast-cancer raster: (a) Single image; (b) 49 numbered 512 × 512 source tiles; (c) crop inspection from the separate analysis #48. The CRC-trained classifier uses raw255 and OpenCV linear resize to 224 × 224. Source: author’s Windows captures.

Reason: Identify the image domain and avoid presenting a cross-domain illustration as validated breast classification.



## 4. Figure 4.4 caption

Before: Figure 4.4. Original/segmentation-overlay comparison for a 3552 × 3536 image, with linked Fit views at 15.7%, opacity 30% and all nine pixel-coverage classes. The displayed analysis is record #49 using the supervisor-provided UPerNet model. Source: author’s Windows capture.

After: Figure 4.4. Original/segmentation-overlay comparison for a 3552 × 3536 breast-cancer raster, with linked Fit views at 15.7%, opacity 30% and nine-class pixel coverage. Record #49 uses the supervisor-provided breast-cancer-trained UPerNet model. Source: author’s Windows capture.

Reason: Use the confirmed image and training domains while retaining the actual displayed parameters.



## 5. 3.6.3

Before: Manual testing supplements automated checks on the actual Windows installation. The evidence checklist records software commit, Python/dependency versions, display scale, available screen geometry, model checksum if available, source dimensions and selected parameters. Each case records expected behaviour, actual behaviour, pass/fail, screenshot/log identifier and tester/date. Untested cases remain marked pending.

After: Manual testing supplements automated checks on the actual Windows installation. Each case records conditions, expected and actual behaviour, outcome and supporting evidence. Appendix D defines 15 cases. The accompanying acceptance workbook consolidates the existing screenshots, PDF and JSON into eight partially evidenced cases and seven cases without a complete execution record. It provides step-by-step instructions and blank execution fields for the remaining checks; this evidence review is separate from a new Windows test session.

Reason: Make the manual protocol usable and distinguish documented observations from unperformed actions.



## 6. 3.6.4

Before: After the tasks, participants complete the unmodified ten SUS items, separate feature ratings and open-ended questions. Completion time, assistance, errors and interpretation responses are recorded. There are no actual participant responses at the time of writing. Appendix B contains the consent briefing, tasks, questionnaire and recording rules; the accompanying workbook is a data-entry/scoring template, not a populated dataset.

After: After the tasks, participants complete the unmodified ten SUS items, separate feature ratings and open-ended questions. Completion time, assistance, errors and interpretation responses are recorded. Participant responses have not yet been collected. Appendix B contains the consent briefing, tasks, questionnaire and recording rules. The response workbook remains blank; a separate synthetic scoring-check workbook tests arithmetic and missing-value handling and is excluded from UAT results.

Reason: Provide usable evaluation materials without treating synthetic inputs as participant evidence.



## 7. Table 4.4 source note

Before: Source: hardware recorded on 19 October 2026 and runtime/dependency records from the completed 27 October invocation. The later collection did not remeasure physical RAM or GPU specifications; its runtime probe directly confirms CPU execution. The records are distinguished by date, and their same-device identity awaits confirmation.

After: Source: hardware recorded on 19 October 2026 and runtime/dependency records from the completed 27 October invocation, collected on the same Windows computer. The later collection did not remeasure RAM or GPU specifications; its runtime probe confirms CPU execution.

Reason: Same-computer identity is now confirmed; preserve the separate measurement dates and CPU-only execution.



## 8. 4.3.3

Before: The supplied Windows screenshots add representative actual-image observations of classification, segmentation, linked display, history/default isolation, export and cancellation. They are not a completed W01–W15 acceptance sheet. Their session source commit was not supplied, so they are not attributed to the automated 3a935ef execution. Figure 4.1, Figure 4.3 and Figure 4.4 retain their actual displayed record IDs; the author confirms that these were direct-run captures, not history-restoration demonstrations.

After: The Windows screenshots document representative actual-image observations of classification, segmentation, linked display, history/default isolation, export and cancellation. Figures 4.1, 4.3 and 4.4 show direct runs and retain their displayed record IDs. The Appendix D evidence register records eight partially evidenced cases and seven without a complete execution record; no new formal Pass or Fail is assigned. Completion of the remaining case sequences is distinct from the 508 automated test passes.

Reason: Replace repetitive screenshot-version caveats with the precise scope of observed manual evidence.



## 9. 4.4

Before: UAT results await collection. Appendix B provides the tasks, questionnaire and scoring rules; the tables below reserve the actual participant and outcome data. H2 and the user-performance component of H3 will be assessed after those responses are available.

After: UAT responses have not yet been collected. Appendix B provides the tasks, questionnaire, response workbook and scoring rules; the tables below reserve actual participant and outcome data. Synthetic scoring checks are kept in a separate workbook and are not included in these tables. H2 and the user-performance component of H3 will be assessed after participant responses are available.

Reason: Keep the empirical study status explicit and prevent scoring fixtures being read as study results.



## 10. 4.5.3

Before: Segmentation is a supervisor-provided model integration with a documented inference procedure. I did not train it, and its training dataset and Dice/IoU report were not obtained. Controlled tests establish software geometry and statistics rather than segmentation accuracy; a real-weight demonstration and aligned ground-truth evaluation remain necessary.

After: Segmentation integrates a supervisor-provided model trained on breast-cancer data. I did not train the model, and the named training dataset, detailed training procedure and Dice/IoU report are unavailable. Figures 4.4 and 4.6 provide real-weight output and report examples. Neither these examples nor the controlled geometry/statistics tests measure segmentation accuracy; evaluation against authorised aligned ground-truth masks is still required.

Reason: Remove the obsolete missing-real-weight-demonstration statement; retain the actual ground-truth evaluation gap.



## 11. 4.5.3

Before: The 508-case Windows suite verifies its source revision under the recorded runtime. Actual Windows captures and a segmentation PDF/JSON document representative image workflows, including overlays, numbered crop inspection, a completed recorded Re-run with parameter isolation, export and acknowledged cancellation. A complete source-stamped manual acceptance record, participant UAT and assistive-technology assessment remain incomplete. The transient Cancelling view was not captured; default-path interaction is shown with an explicitly identified test model.

After: The 508-case Windows suite verifies its source revision under the recorded runtime. Actual Windows captures and a segmentation PDF/JSON document overlays, numbered crop inspection, recorded Re-run parameter isolation, export and acknowledged cancellation. The manual evidence register in Appendix D identifies the remaining case sequences. Participant UAT and assistive-technology assessment are uncompleted. The default-path demonstration uses an explicitly identified test model.

Reason: Consolidate outstanding user/manual evidence without repeated screenshot-source demands.



## 12. Appendix A.3

Before: The evaluated software source and complete Windows regression are recorded. The representative image groups, actual PDF/JSON and completed recorded Re-run evidence have been supplied. Before submission, complete source-stamped formal acceptance and UAT, and supply semester/submission date. Preserve the original scope of classifier evaluation and dated Windows evidence. Performance or deployment claims require the corresponding protocols.

After: The evaluated software source and complete Windows regression are recorded. Representative image groups, actual PDF/JSON and completed recorded Re-run evidence have been supplied. Before submission, complete the remaining manual checks and participant UAT, and supply semester/submission date. Performance or deployment claims require the corresponding measurement protocols.

Reason: Update the practical completion checklist and retain unperformed evaluation boundaries.



## 13. Appendix B.6

Before: The accompanying workbook contains blank participant, task, SUS and feature-rating sheets. SUS scoring requires ten numeric integers in 1–5 and applies Equation 3.4. A blank/incomplete form remains unscored. In task results, independent completion and assistance are separate outcomes; feature “Not used” is excluded from numerical ratings. Store anonymous identifiers consistently across sheets, document exclusions and retain the unmodified raw responses separately.

After: The accompanying response workbook contains blank participant, task, SUS and feature-rating sheets. SUS scoring requires ten numeric integers in 1–5 and applies Equation 3.4; incomplete or invalid forms remain unscored. Independent and assisted task completion are recorded separately, and feature “Not used” is excluded from numerical ratings. A separate workbook, SUS_Scoring_Checks_SYNTHETIC.xlsx, contains six deterministic arithmetic checks, including missing and out-of-range inputs. These are software checks without participants and are excluded from Chapter 4 results.

Reason: Supply checked scoring examples in a separate, unmistakably non-empirical artifact.



## 14. Appendix B.6

Before: For the pilot, report actual N, recruitment method, device conditions, SUS distribution, completion denominators, assistance/errors and qualitative themes. If the study lacks a comparator, describe perceived usability rather than claiming causal improvements in efficiency. Add de-identified quotations only with consent and never fill empty Chapter 4 tables using generated participants.

After: For the pilot, report actual N, recruitment method, device conditions, SUS distribution, completion denominators, assistance/errors and qualitative themes. Without a comparator, describe perceived usability rather than causal improvements in efficiency. Use only consented, de-identified participant responses and quotations; retain original responses separately from calculated scores and the synthetic scoring checks.

Reason: Use neutral academic reporting instructions while preserving the genuine-data requirement.



## 15. Appendix C.1

Before: The new image collection contains direct-run screenshots with analysis timestamps in October and separate History/default demonstrations. The application commit used for these capture sessions was not provided. Accordingly, the figures identify their displayed records rather than assigning the 3a935ef automated-test identity or deriving capture dates from stored record timestamps. The author identifies the custom-default demonstration file as a test model.

After: The image collection contains direct-run screenshots, separate History/default demonstrations and completed recorded Re-run #83 with its parameter view. Figure captions identify the displayed analysis records and distinguish screen results from separate export artifacts. The custom-default demonstration uses an explicitly identified test model.

Reason: Remove repetitive unavailable screenshot-commit discussion without assigning an unsupported revision.



## 16. Table D.1 source note

Before: Source: author’s Windows acceptance protocol. Expected evidence describes the acceptance criterion, not an observed Pass.

After: Source: author’s Windows acceptance protocol. The accompanying workbook records eight cases with partial observations and seven without a complete execution record. Table D.1 defines expected outcomes, not new Pass results.

Reason: Link all 15 unchanged acceptance criteria to the evidence-based workbook status.



## 17. Appendix D.2

Before: Figures 1.1 and 4.1, 4.3–4.6 and 4.9 contain the supplied dataset image and Windows captures, including the completed recorded Re-run #83 and its parameter view. Figures 4.2, 4.7 and 4.8 retain their explicitly labelled development captures. The transient Cancelling view was not captured; running and acknowledgement views are provided. The capture index distinguishes filenames, displayed record timestamps, controlled test-model settings and actual report artifacts. Screenshot-session source identity and the formal acceptance sheets remain separate outstanding records.

After: Figures 1.1 and 4.1, 4.3–4.6 and 4.9 contain the dataset image and Windows captures, including completed recorded Re-run #83 and its parameter view. Figures 4.2, 4.7 and 4.8 retain their labelled development captures. Running and cancellation acknowledgement are documented without requiring a transient Cancelling screenshot. The capture index distinguishes displayed records, test-model configuration and actual report artifacts. The accompanying acceptance workbook records which case sequences remain to be completed.

Reason: Remove redundant screenshot-identity demands and direct remaining verification to concrete manual steps.



## 18. Appendix E.2

Before: The supervisor-provided inference notebook establishes the model configuration and label mapping but contains no independently annotated test-set evaluation. The segmentation training dataset, training procedure and Dice/IoU report were not obtained. A future evaluation requires authorised aligned masks, patient/slide separation, the same label vocabulary, an explicit ignored-label policy and recorded tile/stride/input settings; per-class and aggregate IoU/Dice should then be calculated with documented denominator rules.

After: The supervisor-provided inference notebook establishes the model configuration and label mapping but contains no independently annotated test-set evaluation. The model was trained on breast-cancer data; the named training dataset, training procedure and Dice/IoU report are unavailable. The demonstration raster is also from breast-cancer data, with unknown MPP. Evaluation requires authorised aligned masks, patient/slide separation, the same label vocabulary, an explicit ignored-label policy and recorded tile/stride/input settings. Per-class and aggregate IoU/Dice should then be calculated with documented denominator rules.

Reason: Record the confirmed domains and specify precisely which training and evaluation facts remain unknown.



## 19. Appendix E.2

Before: The 27 October Windows manifest identifies UPerNet_TME_tissue-panoptils_best_model_100ep.pth as 489,488,187 bytes (466.812 MiB), with SHA-256 b4d8956856800fc44b274244713494f63e2791cd31a1b07b1d5223870b408486. The file was present and unchanged before and after the completed regression. This resource identity does not supply missing segmentation training provenance or predictive IoU/Dice measurements.

After: The 27 October Windows manifest identifies UPerNet_TME_tissue-panoptils_best_model_100ep.pth as 489,488,187 bytes (466.812 MiB), with SHA-256 b4d8956856800fc44b274244713494f63e2791cd31a1b07b1d5223870b408486. The file was present and unchanged before and after the completed regression. Its file identity is separate from detailed training provenance and predictive IoU/Dice measurements.

Reason: Retain the genuine resource identity while avoiding an overbroad assertion that no domain provenance is known.



## 20. 3.6.6 / F10–F11

Before: Current Windows automated restore and recorded-rerun cases passed. Follow-up actual captures show completed record #83 retaining recorded crop/input/backend parameters while the current-run setting remains independent. Source-stamped formal manual acceptance and user-efficiency assessment remain separate.

After: Windows automated restore and recorded-rerun cases passed. Actual captures show completed record #83 retaining recorded crop/input/backend parameters while current-run settings remain independent. The acceptance register identifies the remaining manual sequence; user efficiency awaits UAT.

Reason: Retain technical verification and separate the remaining manual/user assessment.



## 21. Appendix C.1 / E24

Before: Representative classification/segmentation display, completed recorded Re-run #83, parameter isolation, export and cancellation; screenshot source revision not supplied; test-model configuration explicitly distinguished.

After: Classification/segmentation display, completed recorded Re-run #83, parameter isolation, actual report and cancellation observations; test-model settings distinguished. The acceptance workbook separates partial observations from unperformed sequences.

Reason: Use concise observed-evidence descriptions without unprovided source attribution.



## 22. Supporting materials / manual acceptance

Before: Blank Windows manual acceptance template.

After: 15-case register and workbook: 8 partially evidenced, 7 not recorded; Chinese action guide and blank actual-execution fields.

Reason: Make the remaining Windows actions clear without fabricating Pass outcomes.



## 23. Supporting materials / UAT

Before: Blank workbook referred to revision 1f3e01e; no separate scoring examples.

After: Blank real-response workbook references 3a935ef; separate prominently labelled synthetic scoring-check workbook contains 6 verified vectors, no participants or empirical conclusions.

Reason: Repair stale instructions and provide valid scoring examples while preserving the uncollected study status.



## 24. Supporting materials / study material register

Before: All study materials were unassigned, including the native224 CRC example and classifier identity.

After: Register identifies the uploaded224×224 TUM patch and its checksum, the genuine classifier checksum, and the actual segmentation report/record. Study reuse permission, local availability, the prescribed1024×768 crop, prepared history record and cancellation workload remain to be confirmed/prepared.

Reason: Reuse actual available identities and specify the exact remaining preparation without inventing permissions or unperformed runs.

