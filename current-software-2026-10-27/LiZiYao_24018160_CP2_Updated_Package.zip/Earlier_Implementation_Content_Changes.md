# 修改位置、前后文本与原因

对照2026-10-20的Windows记录版本。后续功能按实际实现描述；未取得的新Windows/UAT/性能结果没有写成已完成。

## 1. Abstract

**Before**: ZY-Path is a local PyQt5 desktop application for model-aware histopathology classification, combining Single image and Tiled analysis modes, spatial inspection, SQLite history, recorded rerun and export, with a separate supervisor-provided segmentation integration. On 7,180 CRC-VAL-HE-7K patches, the classifier achieved 90.68% accuracy and 88.59% macro-F1 through both the recorded OpenCV/Albumentations pipeline and the application’s default Pillow Single image core, with agreement on all predicted labels. The complete native Windows automated suite passed all 370 tests; UAT, segmentation accuracy, systematic performance measurement and clean-machine deployment remain to be evaluated.

**After**: Deploying pathology models through separate scripts makes preprocessing, spatial sampling and previous analysis settings difficult to inspect. This project develops ZY-Path, a local PyQt5 desktop application that connects supported PyTorch CPU inference to explicit Single image and Tiled analysis controls, spatial inspection, recorded history and export, with a separate supervisor-provided segmentation integration. The classifier achieved 90.68% accuracy and 88.59% macro-F1 on 7,180 native 224 × 224 CRC-VAL-HE-7K patches through the application’s default Pillow core, agreeing with every predicted label from the recorded reference pipeline. The 19 October Windows baseline passed 370 automated tests. The engineering contribution is a model-aware desktop workflow with explicit crop geometry, independent task semantics and reproducible parameter restoration. UAT, final-version manual Windows acceptance, systematic performance measurements and clean-machine deployment remain incomplete.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 2. Abstract

**Before**: List of Tables	ix

**After**: List of Tables	viii

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 3. Abstract

**Before**: 3.2.3 Ethical Considerations	22

**After**: 3.2.3 Ethical Considerations	23

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 4. Abstract

**Before**: 3.3 Methodologies, Tools, and Techniques	23

3.3.1 Model representations and executable validation	23

3.3.2 Classification training and model configuration	24

3.3.3 Classification preprocessing and resize provenance	25

3.3.4 Explicit classification modes and crop geometry	25

3.3.5 Class probabilities, maps and estimated coverage	26

3.3.6 Segmentation pathway and label restoration	27

3.3.7 Background execution and cancellation	29

3.3.8 History schema, artifacts and rerun isolation	29

3.3.9 Export and local model defaults	31

3.4 User Interface (UI) and User Experience (UX) Design	31

3.4.1 Principles and information hierarchy	31

3.4.2 Spatial results and progressive disclosure	32

3.4.3 Control states, settings and help	33

3.4.4 Responsive windows and platform limits	33

3.5 Unified Modeling Language (UML) Diagrams	34

3.5.1 Use Case Diagram	34

3.5.2 Sequence Diagram	35

3.5.3 Class Diagram	36

3.5.4 Activity Diagram	39

3.6 Testing Methodology	40

3.6.1 Development Testing	40

3.6.2 Module Testing and Fallback Handling	40

3.6.3 Manual System Testing	41

3.6.4 User Acceptance Testing (UAT)	41

3.6.5 Testing Summary	42

3.6.6 Requirements Traceability Matrix	42

3.7 Risk Management and Mitigation Strategies	45

3.8 Summary	46

Chapter 4: Results and Discussion	47

4.1 Introduction	47

4.2 System Implementation Results	47

4.2.1 Implemented workflow and scope	47

4.2.2 Classification results and spatial inspection	48

4.2.3 Segmentation results	49

4.2.4 History, rerun and export	50

4.2.5 Settings, cancellation and interface polish	50

4.2.6 Classification training and test results	52

4.3 Functional Testing Results	57

4.3.1 Recorded automated results	57

4.3.2 Challenges, resolutions and evidence	59

4.3.3 Windows startup and window-state observations	61

4.3.4 Runtime and deployment verification status	62

4.4 User Acceptance Testing Results	62

4.4.1 Participant Demographics	62

4.4.2 Quantitative Results	63

4.4.3 Feature Usage and Ratings	64

4.4.4 System Performance and Acceptability	65

4.4.5 Qualitative Feedback Analysis	65

4.5 Discussion	65

4.5.1 Achievement of Research Objectives	65

4.5.2 Comparison with Existing Solutions	67

4.5.3 Limitations and Constraints	67

4.5.4 Implications for Future Development	68

4.6 Summary	69

Chapter 5: Conclusion and Future Work	70

5.1 Conclusion	70

5.2 Future Work and Recommendations	71

5.3 Research Contributions	71

5.4 Summary	72

References	73

I. Peer-Reviewed Journal Articles	73

II. Peer-Reviewed Conference Papers	73

III. Books and Book Chapters	74

IV. Magazine and Technical Articles	74

V. Standards, Documentation, and Online Resources	74

Appendices	76

Appendix A: Project Timeline and Planning	76

A.1 Proposal baseline	76

A.2 Implementation and outstanding milestones	81

A.3 Completion sequence	82

Appendix B: User Acceptance Testing Details	83

B.1 Participant information and consent briefing	83

B.2 Background questions	83

B.3 Standard task script and observation rules	83

B.4 System Usability Scale questionnaire	85

B.5 Feature-specific ratings and open questions	85

B.6 Scoring, missing data and reporting	85

Appendix C: Implementation and Evidence Index	86

C.1 Source baseline	86

C.2 Evidence interpretation	88

Appendix D: Manual Windows Acceptance and Screenshot Checklist	88

D.1 Native acceptance record	88

D.2 Required figure replacements	89

Appendix E: Independent Model Evaluation Protocol	90

E.1 Classification	90

E.2 Segmentation	90

E.3 Runtime and deployment	91

**After**: 3.3 Methodologies, Tools, and Techniques	24

3.3.1 Model representations and executable validation	24

3.3.2 Classification training and model configuration	25

3.3.3 Classification preprocessing and resize provenance	26

3.3.4 Explicit classification modes and crop geometry	27

3.3.5 Class probabilities, maps and estimated coverage	28

3.3.6 Segmentation pathway and label restoration	29

3.3.7 Background execution and cancellation	30

3.3.8 History schema, artifacts and rerun isolation	31

3.3.9 Export and local model defaults	33

3.4 User Interface (UI) and User Experience (UX) Design	34

3.4.1 Principles and information hierarchy	34

3.4.2 Spatial results and progressive disclosure	35

3.4.3 Control states, settings and help	36

3.4.4 Responsive windows and platform limits	36

3.5 Unified Modeling Language (UML) Diagrams	37

3.5.1 Use Case Diagram	37

3.5.2 Sequence Diagram	38

3.5.3 Class Diagram	40

3.5.4 Activity Diagram	40

3.6 Testing Methodology	42

3.6.1 Development Testing	42

3.6.2 Module Testing and Fallback Handling	42

3.6.3 Manual System Testing	43

3.6.4 User Acceptance Testing (UAT)	43

3.6.5 Testing Summary	44

3.6.6 Requirements Traceability Matrix	45

3.7 Risk Management and Mitigation Strategies	47

3.8 Summary	49

Chapter 4: Results and Discussion	50

4.1 Introduction	50

4.2 System Implementation Results	50

4.2.1 Implemented workflow and scope	50

4.2.2 Classification results and spatial inspection	51

4.2.3 Segmentation results	53

4.2.4 History, rerun and export	53

4.2.5 Settings, cancellation and interface polish	54

4.2.6 Classification training and test results	56

4.3 Functional Testing Results	61

4.3.1 Recorded automated results	61

4.3.2 Challenges, resolutions and evidence	63

4.3.3 Windows startup and window-state observations	65

4.3.4 Runtime and deployment verification status	66

4.4 User Acceptance Testing Results	66

4.4.1 Participant Demographics	67

4.4.2 Quantitative Results	67

4.4.3 Feature Usage and Ratings	68

4.4.4 System Performance and Acceptability	69

4.4.5 Qualitative Feedback Analysis	69

4.5 Discussion	70

4.5.1 Achievement of Research Objectives	70

4.5.2 Comparison with Existing Solutions	71

4.5.3 Limitations and Constraints	72

4.5.4 Implications for Future Development	73

4.6 Summary	74

Chapter 5: Conclusion and Future Work	75

5.1 Conclusion	75

5.2 Future Work and Recommendations	76

5.3 Research Contributions	76

5.4 Summary	77

References	78

I. Peer-Reviewed Journal Articles	78

II. Peer-Reviewed Conference Papers	78

III. Books and Book Chapters	79

IV. Magazine and Technical Articles	79

V. Standards, Documentation, and Online Resources	79

Appendices	81

Appendix A: Project Timeline and Planning	81

A.1 Proposal baseline	81

A.2 Implementation and outstanding milestones	86

A.3 Completion sequence	87

Appendix B: User Acceptance Testing Details	88

B.1 Participant information and consent briefing	88

B.2 Background questions	88

B.3 Standard task script and observation rules	89

B.4 System Usability Scale questionnaire	90

B.5 Feature-specific ratings and open questions	91

B.6 Scoring, missing data and reporting	91

Appendix C: Implementation and Evidence Index	92

C.1 Source baseline	92

C.2 Evidence interpretation	93

Appendix D: Manual Windows Acceptance and Screenshot Checklist	94

D.1 Native acceptance record	94

D.2 Required figure replacements	95

Appendix E: Independent Model Evaluation Protocol	96

E.1 Classification	96

E.2 Segmentation	96

E.3 Runtime and deployment	97

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 5. List of Figures

**Before**: Figure 3.2. Annotated final workflow wireframe. This author-created design diagram summarises implemented regions and is not a Windows runtime screenshot.	32

Figure 3.3. Use case diagram for the implemented local analysis workflow. File/model trust and clinical interpretation remain external responsibilities. Source: author, based on the implemented application.	35

Figure 3.4. Sequence diagram for a run and its persistence boundary. Cancellation is acknowledged after a safe checkpoint; artifact-save failures must not be represented as successful saved records. Source: author, based on the implemented application.	36

Figure 3.5. Implementation-level class diagram. Relationships represent principal ownership or dependency, not a generated inventory of every method. Source: author, based on the implemented application.	38

Figure 3.6. Activity diagram from parameter selection to completed persistence, with safe cancellation and error exits. Source: author, based on the implemented application.	39

Figure 4.1. Final Windows application overview (evidence pending; replace this reserved area with the actual authorised capture).	48

Figure 4.2. Tiled classification interface with source/result comparison and revised result toggles. Source: author’s Linux/offscreen-Qt development capture; synthetic fixture, not a model result.	48

Figure 4.3. Real-weight single-image and tiled classification evidence (evidence pending; replace this reserved area with the actual authorised capture).	49

Figure 4.4. Windows segmentation result and aligned comparison (evidence pending; replace this reserved area with the actual authorised capture).	49

Figure 4.5. History and recorded-parameter rerun (evidence pending; replace this reserved area with the actual authorised capture).	50

Figure 4.6. Exported report and companion artifacts (evidence pending; replace this reserved area with the actual authorised capture).	50

Figure 4.7. Implemented Guide & Support page with persistent Contents navigation and numbered guidance. Source: author’s Linux/offscreen-Qt development capture; this is interface evidence.	51

Figure 4.8. English history-calendar popup with a simulated Chinese default locale. Source: author’s Linux/offscreen-Qt development capture; the selected date is test input.	52

Figure 4.9. Cancellation and per-task model defaults on Windows (evidence pending; replace this reserved area with the actual authorised capture).	52

Figure 4.10. Classification training and validation over 30 recorded epochs, with the selected epoch 26 marked. Source: author’s plot of experiments/crc-dn21-seed42-10ep/metrics.csv.	53

Figure 4.11. Nine-class confusion matrix for CRC-VAL-HE-7K. Source: the classification experiment’s saved matrix; the Windows default-Pillow predictions independently reproduce every count. Rows are true labels and columns predicted labels.	55

Figure 4.12. Completed Windows pytest report, 19 October 2026. Source: the recorded full-suite log; selected text is reproduced with omissions marked.	59

**After**: Figure 3.2. Annotated final workflow wireframe. This author-created design diagram summarises implemented regions and is not a Windows runtime screenshot.	34

Figure 3.3. Use case diagram for the implemented local analysis workflow. File/model trust and clinical interpretation remain external responsibilities. Source: author, based on the implemented application.	38

Figure 3.4. Sequence diagram for a run and its persistence boundary. Cancellation is acknowledged after a safe checkpoint; artifact-save failures must not be represented as successful saved records. Source: author, based on the implemented application.	39

Figure 3.5. Implementation-level class diagram. Relationships show selected coordination dependencies and worker inheritance. Source: author, based on the implemented application.	40

Figure 3.6. Activity diagram from parameter selection to completed persistence, with safe cancellation and error exits. Source: author, based on the implemented application.	41

Figure 4.1. Final Windows application overview (evidence pending; replace this reserved area with the actual authorised capture).	51

Figure 4.2. Tiled classification interface with source/result comparison and revised result toggles. Source: author’s Qt-simulated development capture; synthetic fixture, not a model result.	52

Figure 4.3. Real-weight single-image and tiled classification evidence (evidence pending; replace this reserved area with the actual authorised capture).	52

Figure 4.4. Windows segmentation result and aligned comparison (evidence pending; replace this reserved area with the actual authorised capture).	53

Figure 4.5. History and recorded-parameter rerun (evidence pending; replace this reserved area with the actual authorised capture).	54

Figure 4.6. Exported report and companion artifacts (evidence pending; replace this reserved area with the actual authorised capture).	54

Figure 4.7. Implemented Guide & Support page with persistent Contents navigation and numbered guidance. Source: author’s Qt-simulated development capture; this is interface evidence.	55

Figure 4.8. English history-calendar popup with a simulated Chinese default locale. Source: author’s Qt-simulated development capture; the selected date is test input.	56

Figure 4.9. Cancellation and per-task model defaults on Windows (evidence pending; replace this reserved area with the actual authorised capture).	56

Figure 4.10. Classification training and validation over 30 recorded epochs, with the selected epoch 26 marked. Source: author’s plot of experiments/crc-dn21-seed42-10ep/metrics.csv.	57

Figure 4.11. Nine-class confusion matrix for CRC-VAL-HE-7K. Source: the classification experiment’s saved matrix; the Windows default-Pillow predictions independently reproduce every count. Rows are true labels and columns predicted labels.	59

Figure 4.12. Completed Windows pytest report, 19 October 2026. Source: the recorded full-suite log; selected text is reproduced with omissions marked.	63

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 6. List of Tables

**Before**: Table 3.3. Classification class order and fixed display palette v1	27

Table 3.4. Built-in segmentation labels and display colours	28

Table 3.5. Implemented persistent data structures	30

Table 3.6. Requirements traceability matrix	43

Table 3.7. Risk register and residual mitigations	45

Table 4.1. Classification evaluation summary	53

Table 4.2. Class-wise classification performance on 7,180 test images	54

Table 4.3. Final Windows automated test result	57

Table 4.4. Windows test host and actual CPU runtime on 19 October 2026	58

Table 4.5. Implementation challenges and verified resolutions	59

Table 4.6. UAT participant profile — awaiting actual responses	62

Table 4.7. UAT quantitative summary — awaiting valid data	63

Table 4.8. Feature ratings — awaiting actual use and responses	64

Table 4.9. Objective achievement and outstanding evidence	66

Table A.1. Original CP1 planning baseline, retained from the submitted proposal	76

Table A.2. Original CP2 planning baseline, retained from the submitted proposal	78

Table A.3. Evidence-based milestone status	81

Table B.1. UAT tasks and success criteria	84

Table C.1. Principal evidence sources	86

Table C.2. Windows automated test execution history	88

Table D.1. Final Windows acceptance cases	89

**After**: Table 3.3. Classification class order and fixed display palette v1	28

Table 3.4. Built-in segmentation labels and display colours	30

Table 3.5. Implemented persistent data structures	31

Table 3.6. Requirements traceability matrix	45

Table 3.7. Risk register and residual mitigations	48

Table 4.1. Classification evaluation summary	57

Table 4.2. Class-wise classification performance on 7,180 test images	58

Table 4.3. Completed Windows automated execution with its source version. Source: the recorded Windows log, XML result and exit status.	61

Table 4.4. Windows test host and actual CPU runtime on 19 October 2026	62

Table 4.5. Implementation challenges and verified resolutions	63

Table 4.6. UAT participant profile — awaiting actual responses	67

Table 4.7. UAT quantitative summary — awaiting valid data	67

Table 4.8. Feature ratings — awaiting actual use and responses	68

Table 4.9. Objective achievement and outstanding evidence	70

Table A.1. Original CP1 planning baseline, retained from the submitted proposal	81

Table A.2. Original CP2 planning baseline, retained from the submitted proposal	83

Table A.3. Evidence-based milestone status	86

Table B.1. UAT tasks and success criteria	89

Table C.1. Principal evidence sources	92

Table C.2. Windows automated execution history.	94

Table D.1. Final Windows acceptance cases	94

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 7. 1.2 Problem Formulation

**Before**: The original research questions remain relevant to this implemented scope:

**After**: The research questions guide the implemented scope and its evaluation:

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 8. 1.5 Scope of Work

**Before**: Local execution requires the selected model files and, for UPerNet reconstruction, its verified configuration in the local Hugging Face cache. Windows source execution and real-classifier validation are documented in Section 4.3.3; offline package verification is addressed separately in Section 4.3.4.

**After**: Local source execution requires the selected model files and the verified UPerNet configuration in the local Hugging Face cache. Frozen-build support instead packages that configuration with the application. Windows source execution and real-classifier validation are documented in Section 4.3.3; building and validating a clean-machine offline distribution remain separate activities in Section 4.3.4.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 9. 2.3.2 Slideflow and Slideflow Studio

**Before**: Slideflow supports deep-learning development for digital histopathology, with slide processing, model training and real-time whole-slide visualisation (Dolezal et al., 2024). Its official repository explicitly describes Slideflow Studio, model-development functionality, stain-processing tools and visualisation. These documented capabilities correct the proposal's implication that Slideflow is only a command-line framework.

**After**: Slideflow supports deep-learning development for digital histopathology, with slide processing, model training and real-time whole-slide visualisation (Dolezal et al., 2024). Its official repository explicitly describes Slideflow Studio, model-development functionality, stain-processing tools and visualisation.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 10. 2.6 Technological Infrastructure and Implementation Considerations

**Before**: UPerNet reconstruction loads its configuration from the local Hugging Face cache with local_files_only=True. Preparing a redistributable application therefore requires packaging the permitted weights, cached configuration and runtime dependencies. PyInstaller is a candidate tool for this future deployment step (PyInstaller Development Team, n.d.); the current deployment evidence is assessed in Section 4.3.4.

**After**: Source-based UPerNet reconstruction loads its configuration from the local Hugging Face cache with local_files_only=True. The Windows build script and PyInstaller specification now describe how to collect the permitted weights, verified configuration, report font and runtime dependencies (PyInstaller Development Team, n.d.). Frozen execution reads the bundled configuration. These implemented build preparations are distinct from an actual version-matched build and clean-machine offline acceptance, whose status is assessed in Section 4.3.4.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 11. 3.1 Overview of System Methodology

**Before**: The implementation is identified by revision 7bd3552. Classification methods are documented by the training code provided by my supervisor, my training/validation records and the corresponding test outputs. The segmentation pathway follows the model and reference inference notebook provided by my supervisor. Appendix C identifies the software version and the source content evaluated in the final Windows run.

**After**: The current implementation is identified by revision 8c4830c. The completed Windows baseline is revision 7bd3552; its date and source version are retained when reporting the automated results. Classification methods are documented by the training code provided by my supervisor, my training/validation records and the corresponding test outputs. The segmentation pathway follows the model and reference inference notebook provided by my supervisor. Appendix C identifies the source versions and Windows execution records.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 12. 3.2.1 Functional Requirements / table 3 row 6

**Before**: F05 | Show classification statistics | Nine-class legend, per-tile label/confidence and actual-area estimates agree with stored tiles

**After**: F05 | Show classification statistics | Nine-class legend, numbered tiles, linked image/table selection, original-crop preview, per-tile confidence and actual-area estimates agree with stored tiles

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 13. 3.2.1 Functional Requirements / table 3 row 8

**Before**: F07 | Inspect spatial results | Overlay/map/original, opacity, comparison, linked navigation and appropriate grid remain aligned

**After**: F07 | Inspect spatial results | Overlay/map/original, opacity, linked navigation and vector grid remain aligned during zoom, panning and divider resizing

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 14. 3.2.1 Functional Requirements / table 3 row 13

**Before**: F12 | Export results | PNG/PDF contain the selected presentation and available recorded metadata

**After**: F12 | Export results | PNG/PDF retain recorded identity/statistics; PDF quality is selectable, background export can be cancelled and an existing destination is replaced only after successful completion

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 15. 3.2.1 Functional Requirements / table 3 row 16

**Before**: F15 | Configure analysis and interface preferences | Mode/default selection, source tile dimensions and resize method persist with clear scope

**After**: F15 | Configure analysis and interface preferences | Mode, tile dimensions and resize method persist; ordinary Run uses current preferences and Re-run uses the selected record snapshot

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 16. 3.2.1 Functional Requirements / table 3 row 18

**Before**: [New content]

**After**: F17 | Clear the workspace and history selection | Clear view removes transient input/result/session state while retaining saved history/files/settings; Clear Selection leaves no selected history row

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 17. 3.2.2 Non-Functional Requirements / table 4 row 5; 3.2.2 Non-Functional Requirements / table 4 row 6

**Before**: N04 | Readable/resizable interface | Small logical screens, font/DPI simulation, theme and focus tests | Native Windows automated layout/window-state checks passed; complete device/accessibility manual acceptance pending.

N05 | Measurable runtime/resource use | Planned fixed-workload benchmark with CPU/RAM/image/tile details | No independent performance benchmark is available

**After**: N04 | Readable/resizable interface | Small logical screens, font/DPI simulation, theme and focus tests | Windows baseline layout checks are recorded; final-version native Windows and assistive-technology manual acceptance remain pending.

N05 | Measurable runtime/resource use | Fixed-workload CPU timings with predefined repetitions, separate cold/warm cases, file sizes and process memory | No independent performance benchmark is available

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 18. 3.2.2 Non-Functional Requirements / table 4 row 8; 3.2.2 Non-Functional Requirements / table 4 row 9

**Before**: N07 | Deployable offline runtime | Local configuration/weights and clean-machine packaging checks | Real classifier loads on Windows; complete offline package and clean-machine deployment unverified

N08 | Maintainability and regression control | Layered modules, named tests, source revision and preserved failure reporting | No current coverage percentage is claimed

**After**: N07 | Deployable offline runtime | Local configuration/weights and clean-machine packaging checks | Build script/specification and local-resource checks implemented; actual packaged artifact, clean-machine and offline acceptance unverified

N08 | Maintainability and regression control | Layered modules, named tests, source revision and preserved failure reporting | Regression requirements are linked to named cases and source versions; a passing test count is not a code-coverage percentage.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 19. 3.2.2 Non-Functional Requirements

**Before**: The CP1 target of at least 80% coverage of core/data remains an unmeasured target because the recorded pytest commands did not generate a coverage report. Requirements therefore retain separate implementation and verification status rather than inferring coverage from the number of passing tests.

**After**: The CP1 core/data coverage target remains an evaluation objective in the proposal baseline. This edition reports the completed Windows automated execution with its source version and named assertions; it does not infer code coverage from the number of passing cases. Requirements retain separate implementation and verification status.

The final acceptance record must state its tested logical window sizes and display scales, whether essential controls remain reachable, and any failure to resize or restore. Performance observations will use the predefined workload and timing boundaries in Appendix E.3. Thresholds requiring user or institutional agreement remain protocol decisions rather than retrospectively selected pass criteria.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 20. 3.3.1 Model representations and executable validation

**Before**: [New content]

**After**: The application loads and runs PyTorch models on CPU; no OpenVINO conversion or runtime is implemented. The genuine classification checkpoint occupies 1,726,089 bytes (1.646 MiB). Its checksum is recorded in Appendix E.1. A segmentation file-size measurement has not been supplied, and there is no converted-model size to report. Structural compatibility permits supported model representations, not arbitrary task or label semantics.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 21. 3.3.2 Classification training and model configuration

**Before**: [New content]

**After**: The augmentation order and parameters are reproducible from the training script: Resize(224, 224); VerticalFlip(p=0.5); HorizontalFlip(p=0.5); HueSaturationValue(hue_shift_limit=(-25, 0), sat_shift_limit=0, val_shift_limit=0, p=1); Rotate(p=1, border_mode=cv2.BORDER_CONSTANT, value=0); RandomSizedCrop((224, 224), 224, 224); and ToTensorV2 followed by float conversion. Arguments not explicitly set use the defaults of the recorded Albumentations 1.3.1 environment. Because the crop height range is fixed at 224 after resizing to 224 × 224, this crop operation does not provide evidence of training with different source fields of view.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 22. 3.3.2 Classification training and model configuration

**Before**: [New content]

**After**: Class weights are calculated as w_c = 1 − n_c / Σ_j n_j from the training counts; they are not inverse-frequency weights. Cross-entropy uses a summed reduction, with epoch reporting normalised by the accumulated class-weight denominator. The script seeds Python, NumPy, PyTorch and the data-loader generator with 42, seeds workers from their PyTorch worker seed, disables cuDNN benchmarking and requests deterministic cuDNN behaviour. Continuation restores the model, optimizer and scheduler states. The reported results describe this recorded run; no multi-seed training-variation study was conducted.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 23. 3.3.4 Explicit classification modes and crop geometry

**Before**: Source crop dimensions determine the field of view before resampling to 224 × 224. The dataset’s nominal source-patch dimensions and resolution are documented in Section 4.2.6. The interface retains 512 × 512 as an editable starting value; its physical-scale equivalence to the training data is unverified for an arbitrary uploaded image. The evaluation consequences are discussed in Section 4.5.3.

**After**: Source crop dimensions determine the field of view before resampling to 224 × 224. At the source dataset’s nominal 0.5 μm/pixel, a 224-pixel edge spans 112 μm. If a new raster’s resolution r is known in μm/pixel, a candidate crop edge covering that field is approximately 112/r pixels; this is a physical-scale calculation, not evidence of optimal predictive performance. The interface retains 512 × 512 as an editable starting value. Values such as 256 and 300 are exploratory source-crop candidates, while the network input remains 224 × 224. A controlled comparison should keep the crop centre, source image, model, backend and display dimensions fixed. No outcomes from those new-size trials are supplied here.

Ordinary Run Inference snapshots the current preference width, height and resize backend at launch. Restoring a history result does not replace those new-run defaults. Re-run alone supplies the recorded parameter snapshot, and the input summary returns to current preferences when it finishes. A change made while inference is active applies to the next run. The 11-case preference-lifetime regression verifies actual crop boxes, recorded geometry, same-value re-entry, mode/image changes, clear view and parameter isolation.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 24. 3.3.8 History schema, artifacts and rerun isolation

**Before**: [New content]

**After**: Clear view removes the current input, visible result and session metadata and clears history selection. It does not delete saved analyses or source files. Clear Selection, Esc in the history table and a click on empty table space can leave no row selected. Restoring history also synchronises the left-side original-image thumbnail; the completed record retains its own identity independently of subsequent model selections.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 25. 3.3.9 Export and local model defaults

**Before**: [New content]

**After**: PdfExportWorker snapshots the selected result, metadata, map and export options before background generation. Progress and cooperative cancellation keep the GUI responsive; the destination is atomically replaced only after a complete report is written. Standard PDF quality is the default: report display copies are sized for up to 300 DPI, large photographs and overlays use high-quality JPEG, and class maps use nearest-neighbour resizing with lossless encoding. Original resolution retains full image pixels with lossless encoding. Text, numerical tables, predictions, saved masks and source files are unchanged. The report distinguishes original image dimensions from display-copy quality and an export-time file checksum from an identity actually recorded at inference.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 26. 3.3.9 Export and local model defaults

**Before**: [New content]

**After**: The inference panel’s built-in/custom selector is a session choice. Selecting the built-in model clears the visible local-model filename while remembering that local choice for a later explicit return in the same session. This does not change either task’s saved startup default or relabel the completed result’s Session metadata. Interrupted custom validation is resumed when required rather than leaving a stale loading state.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 27. 3.4.2 Spatial results and progressive disclosure

**Before**: [New content]

**After**: Tile boundaries and optional one-based tile numbers are drawn in source coordinates. Selecting a tile in an image or its detail row locates the same numbered crop and displays its original pixels, rectangle, label and confidence. The Square action copies the current width to the height once; dimensions remain independently editable. Numeric preference controls route wheel input to page scrolling. The expandable resize guide explains the available backends without changing the model or network input size.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 28. 3.4.2 Spatial results and progressive disclosure

**Before**: [New content]

**After**: Linked panning updates the peer view without repeatedly recentering the actively dragged pane. Resizing retains the intended source-coordinate centre, and divider dragging uses a rubber-band preview before the panes resize on release. Fractional wheel deltas produce proportional zoom while zero or horizontal-only deltas do not trigger an unintended zoom. These operations affect presentation and leave analysis values unchanged.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 29. 3.4.4 Responsive windows and platform limits

**Before**: Automated checks cover small logical screens, repeated narrow/wide transitions and Qt scale-factor simulation. The final native Windows suite also passed the maximise/restore, saved-geometry, comparison/grid and compact-viewport cases. Formal end-to-end acceptance with authorised real images remains a separate activity in Appendix D.

**After**: Automated checks address small logical screens, repeated narrow/wide transitions and Qt scale-factor simulation. The 19 October Windows baseline passed its maximise/restore, saved-geometry, comparison/grid and compact-viewport cases. Subsequent navigation and parameter-lifetime refinements require final-version native Windows manual acceptance with authorised real images in Appendix D.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 30. 3.5.1 Use Case Diagram

**Before**: The primary actor is an educational/research user. No administrator or clinical approval role is implemented. Model validation is included in the run workflow; tiled classification extends the classification choice when that explicit mode is selected. Restoring history and rerunning history are separate use cases because only the latter executes inference and creates a new record. Figure 3.3 maps the actor to the implemented use cases.

**After**: The primary actor is an educational/research user. No administrator or clinical approval role is implemented. Selecting a model includes compatibility validation. Tiled analysis is an explicit classification variant. Restore saved result and Re-run recorded analysis are separate use cases because only rerun performs inference and creates a new record; Search/filter locates records without executing either operation. Figure 3.3 maps these actions and their scope.

**Reason**: Correct the UML to match implemented responsibilities, action-specific parameters and guarded outcomes.

## 31. 3.5.2 Sequence Diagram

**Before**: The sequence diagram follows a successful completed run after the user selects an image, task and model. MainWindow captures parameters, starts the worker and receives progress/result signals. The worker validates and executes the pipeline; the GUI coordinator renders the result, saves artifacts and inserts a history record. Cancellation and saving failure are alternatives, not successful completed-history paths. Figure 3.4 shows the interaction sequence and the alternative cancellation and persistence-failure paths.

**After**: The sequence diagram follows a run after image, task and model selection. MainWindow snapshots the current preferences for ordinary Run or the selected record for Re-run, then starts the worker. Signals deliver progress and a completed result. The coordinator saves completed artifacts and inserts a record only after successful persistence. Figure 3.4 uses guarded alternative fragments for cancellation, pipeline error and persistence failure; these exits are distinct from completed history.

**Reason**: Correct the UML to match implemented responsibilities, action-specific parameters and guarded outcomes.

## 32. 3.5.3 Class Diagram

**Before**: The class diagram shows principal runtime responsibilities rather than every widget. MainWindow coordinates panels and services; InferenceEngine depends on the loader, preprocessor, parser and task-specific spatial functions. ClassificationResult and SegmentationResult share ImageComparison and ZoomableImageView. DatabaseManager and ExportManager handle persistence/export; QSettings stores preferences separately. Figure 3.5 identifies these classes and their principal dependencies.

Figure 3.5. Implementation-level class diagram. Relationships represent principal ownership or dependency, not a generated inventory of every method. Source: author, based on the implemented application.

**After**: The class diagram shows selected runtime responsibilities rather than every widget. MainWindow coordinates input, history, inference, persistence and export. InferenceEngine depends on model loading, preprocessing and output parsing. PdfExportWorker delegates report generation to ExportManager. Spatial result pages use ImageComparison and ZoomableImageView. Figure 3.5 distinguishes coordination dependencies and worker inheritance for the current implementation.

Figure 3.5. Implementation-level class diagram. Relationships show selected coordination dependencies and worker inheritance. Source: author, based on the implemented application.

**Reason**: Correct the UML to match implemented responsibilities, action-specific parameters and guarded outcomes.

## 33. 3.5.4 Activity Diagram

**Before**: The activity diagram highlights the explicit mode decision, distinct preprocessing/task branches and completion/cancellation outcomes. It prevents a misleading conceptual flow in which image dimensions alone choose tiled classification or a cancellation request immediately terminates a model operation. Figure 3.6 traces these decisions through successful completion, cancellation and error exits.

**After**: The activity diagram distinguishes current-preference Run from recorded-parameter Re-run before selecting the task/mode pathway. Classification crops and segmentation processing regions retain independent geometry. Cancellation is checked at safe points before/after model work and between processing regions. Figure 3.6 labels the decisions and success/error exits; a request does not forcibly interrupt a running forward operation.

**Reason**: Correct the UML to match implemented responsibilities, action-specific parameters and guarded outcomes.

## 34. 3.6.4 User Acceptance Testing (UAT)

**Before**: The planned pilot retains the CP1 target of approximately 8–10 participants, subject to recruitment, consent and institutional requirements. Participants should include intended educational/research users with varied programming and pathology experience. Recruitment is purposive/convenience sampling rather than a representative clinical sample; results should be reported accordingly.

Participants receive the same orientation and authorised sample files, then attempt a fixed task sequence: load/classify an image; select tiled analysis and inspect a tile; explain tile coverage versus confidence; compare aligned source/result regions; inspect segmentation; locate and restore history; rerun after changing current defaults; export; cancel; and configure/restore a task-specific model default. Assisted completion is recorded separately from independent completion. Cancellation is judged against the intended safe-stop outcome, not the speed of killing a thread.

**After**: The planned pilot targets approximately 8–10 intended educational/research users, subject to recruitment, consent and institutional requirements. Purposive/convenience recruitment should include varied programming and pathology experience. Protocol revision 1.0 in Appendix B fixes material identifiers, task geometry, assistance categories and stop rules before the first participant; selecting and authorising the actual material pack remains a prerequisite. This is a formative usability study, not a representative clinical sample.

Participants receive the same five-minute orientation and the approved material pack, then attempt the ten tasks in Table B.1. P01 is an authorised native 224 × 224 classification patch; P02 is an authorised 1024 × 768 raster crop prepared consistently from its source; S01 is a saved real-model segmentation record. R01 is a prepared P02 classification record using 256 × 256 source tiles and Pillow bilinear. Those dimensions standardise the interaction task and are not a validated training-scale recommendation. T07 explicitly contrasts Re-run of R01 with ordinary Run after changing current dimensions to 512 × 512. Actual filenames, checksums, permissions and the tested commit must be entered in the supplied material register before testing.

**Reason**: Define prospective study materials and observable task outcomes without inventing participants or responses.

## 35. 3.6.5 Testing Summary

**Before**: Automated results are labelled by environment, date and software version. On 19 October 2026, the final native Windows invocation completed all 370 tests with no failures, errors or skips. Table 4.3 presents this completed result; Appendix C retains the preceding regression subset and earlier execution history.

**After**: The completed Windows baseline on 19 October 2026 passed 370 tests without failures, errors or skipped cases. Table 4.3 reports that execution with its source revision. Related subsets and earlier Windows interruptions remain separately identified in Appendix C; their counts are not added to the complete-suite total.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 36. 3.6.6 Requirements Traceability Matrix / table 8 row 2; 3.6.6 Requirements Traceability Matrix / table 8 row 3; 3.6.6 Requirements Traceability Matrix / table 8 row 4; 3.6.6 Requirements Traceability Matrix / table 8 row 5; 3.6.6 Requirements Traceability Matrix / table 8 row 6; 3.6.6 Requirements Traceability Matrix / table 8 row 7; 3.6.6 Requirements Traceability Matrix / table 8 row 8; 3.6.6 Requirements Traceability Matrix / table 8 row 9; 3.6.6 Requirements Traceability Matrix / table 8 row 10; 3.6.6 Requirements Traceability Matrix / table 8 row 11; 3.6.6 Requirements Traceability Matrix / table 8 row 12; 3.6.6 Requirements Traceability Matrix / table 8 row 13; 3.6.6 Requirements Traceability Matrix / table 8 row 14; 3.6.6 Requirements Traceability Matrix / table 8 row 15; 3.6.6 Requirements Traceability Matrix / table 8 row 16

**Before**: F01 / O3 | InferencePanel; image opening in InferenceEngine | test_inference_panel.py; test_inference_engine.py | Windows full-suite image-loading and input-error cases passed; representative real-image manual tasks pending.

F02 / O2 | ModelLoader; ModelValidationThread | test_model_loader.py | Windows loader/probe and built-in-path cases passed; real-classifier validation recorded. Arbitrary-model semantic compatibility is outside this check.

F03 / O3 | Preprocessor; OutputParser | test_preprocessor.py; test_output_parser.py; test_inference_engine.py | Windows software cases passed; default-Pillow patch accuracy 90.68%, macro-F1 88.59% on native 224 × 224 inputs (Section 4.2.6).

F04–F05 / O3–O4 | ClassificationTileSpec; predict_classification_tiles | test_classification_tiles.py; test_classification_modes_display.py | Windows crop, mode, legend and actual-area fixture cases passed; tiled-map predictive evaluation pending.

F06 / O3–O4 | large_image_segmentation; SegmentationResult | test_large_image_segmentation.py; test_segmentation_results_layout.py | Windows synthetic segmentation geometry/statistics and display cases passed; real-weight demonstration and ground-truth evaluation pending.

F07 / O4 | ImageComparison; ZoomableImageView | test_linked_image_comparison.py; test_screen_fit_and_tile_grid.py | Windows coordinate, linked-view, Fit/zoom/grid and compact-viewport cases passed; formal real-image manual acceptance pending.

F08 / O6 | DatabaseManager; MainWindow artifact saving | test_database_manager.py; test_main_window_inference.py | Windows persistence and artifact cases passed with temporary test records; real-image manual workflow evidence pending.

F09 / O7 | HistoryPanel search/local-date queries | test_history_panel.py; test_result_controls_and_calendar.py | Windows query, calendar and history-interaction cases passed; user task outcomes await UAT.

F10–F11 / O7 | Stored restoration and recorded rerun | test_main_window_rerun.py; test_classification_modes_display.py | Windows restore and recorded-model/mode/parameter rerun cases passed; user-efficiency assessment awaits UAT.

F12 / O5 | ExportManager and export coordinator | test_export_manager.py; test_main_window_export.py | Windows file/report and recorded-metadata cases passed; final real-image report screenshots pending.

F13 / O1 | Cooperative cancel and close lifecycle | test_cancellation_and_model_defaults.py; test_worker_lifetime.py | Windows cooperative-stop, late-result and destruction/callback lifecycle cases passed; real-model manual cancellation record pending.

F14–F15 / O1–O3 | ModelSettingsPage; SettingsDialog; QSettings | test_cancellation_and_model_defaults.py; test_preferences_interaction.py | Windows defaults, validation, preferences and history-isolation cases passed.

F16 / O6–O7 | Confirmed record/artifact deletion | test_main_window_delete.py; test_database_manager.py | Windows app-owned artifact cleanup and source-preservation cases passed.

N01, N04 / O1, O4 | Worker signals; logical screen bounds; scroll layouts | test_window_lifecycle_and_theme.py; test_settings_polish_and_resize.py | Windows window-state, restore, small-viewport and layout cases passed; multi-monitor/assistive-technology manual acceptance pending.

N02, N06 / O2, O6–O7 | Metadata validation and explicit errors | test_main_window_rerun.py; test_cancellation_and_model_defaults.py | Windows missing-file/error handling and recorded-parameter cases passed; immutable provenance is not implemented.

**After**: F01 / O3 | InferencePanel; image opening in InferenceEngine | test_inference_panel.py; test_inference_engine.py | Windows-baseline full-suite image-loading and input-error cases passed; representative real-image manual tasks pending.

F02 / O2 | ModelLoader; ModelValidationThread | test_model_loader.py | Windows baseline loader/probe and built-in-path cases passed. Supported model-loading and task-default checks are implemented. Probe checks do not validate semantic accuracy; current-version native acceptance remains pending.

F03 / O3 | Preprocessor; OutputParser | test_preprocessor.py; test_output_parser.py; test_inference_engine.py | Windows-baseline software cases passed; default-Pillow patch accuracy 90.68%, macro-F1 88.59% on native 224 × 224 inputs (Section 4.2.6).

F04–F05 / O3–O4 | ClassificationTileSpec; predict_classification_tiles | test_classification_tiles.py; test_classification_modes_display.py | Windows-baseline crop, mode, legend and actual-area fixture cases passed; tiled-map predictive evaluation pending.

F06 / O3–O4 | large_image_segmentation; SegmentationResult | test_large_image_segmentation.py; test_segmentation_results_layout.py | Windows-baseline synthetic segmentation geometry/statistics and display cases passed; real-weight demonstration and ground-truth evaluation pending.

F07 / O4 | ImageComparison; ZoomableImageView | test_linked_image_comparison.py; test_screen_fit_and_tile_grid.py | Windows-baseline coordinate, linked-view, Fit/zoom/grid and compact-viewport cases passed; formal real-image manual acceptance pending.

F08 / O6 | DatabaseManager; MainWindow artifact saving | test_database_manager.py; test_main_window_inference.py | Windows-baseline persistence and artifact cases passed with temporary test records; real-image manual workflow evidence pending.

F09 / O7 | HistoryPanel search/local-date queries | test_history_panel.py; test_result_controls_and_calendar.py | Windows-baseline query, calendar and history-interaction cases passed; user task outcomes await UAT.

F10–F11 / O7 | Stored restoration and recorded rerun | test_main_window_rerun.py; test_classification_modes_display.py; test_tile_preferences_lifetime.py | Windows-baseline restore and recorded-model/mode/parameter rerun cases passed; user-efficiency assessment awaits UAT.

F12 / O5 | ExportManager and export coordinator | test_export_manager.py; test_main_window_export.py; test_background_pdf_export.py; test_pdf_report_layout.py; test_pdf_image_quality.py | Windows-baseline file/report and recorded-metadata cases passed; final real-image report screenshots pending.

F13 / O1 | Cooperative cancel and close lifecycle | test_cancellation_and_model_defaults.py; test_worker_lifetime.py | Windows-baseline cooperative-stop, late-result and destruction/callback lifecycle cases passed; real-model manual cancellation record pending.

F14–F15 / O1–O3 | ModelSettingsPage; SettingsDialog; QSettings | test_cancellation_and_model_defaults.py; test_preferences_interaction.py | Windows-baseline defaults, validation, preferences and history-isolation cases passed.

F16 / O6–O7 | Confirmed record/artifact deletion | test_main_window_delete.py; test_database_manager.py | Windows-baseline app-owned artifact cleanup and source-preservation cases passed.

N01, N04 / O1, O4 | Worker signals; logical screen bounds; scroll layouts | test_window_lifecycle_and_theme.py; test_settings_polish_and_resize.py | Windows-baseline window-state, restore, small-viewport and layout cases passed; multi-monitor/assistive-technology manual acceptance pending.

N02, N06 / O2, O6–O7 | Metadata validation and explicit errors | test_main_window_rerun.py; test_cancellation_and_model_defaults.py | Windows-baseline missing-file/error handling and recorded-parameter cases passed; immutable provenance is not implemented.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 37. 3.6.6 Requirements Traceability Matrix / table 8 row 18; 3.6.6 Requirements Traceability Matrix / table 8 row 19; 3.6.6 Requirements Traceability Matrix

**Before**: N05, N07–N08 / O1 | Runtime/deployment/regression process | Recorded pytest logs; planned benchmark/package protocol | Windows full suite: 370 passed, 0 failed/errors/skipped; repeated benchmark, clean package and coverage measurement pending.

Source: named project tests and the completed native Windows full-suite log/XML of 19 October 2026, together with the classifier evaluation.

**After**: N05, N07–N08 / O1 | Runtime/deployment/regression process | Recorded pytest logs; planned benchmark/package protocol | Windows baseline: 370 passed, no failures/errors/skips. Repeated performance measurement and clean-machine deployment remain incomplete. Later changes require current-version Windows execution.

F17 / O1, O6–O7 | MainWindow; InferencePanel; HistoryPanel | test_clear_view_and_history_sync.py | Clear-view, zero-selection, history-thumbnail and source-preservation behaviour is implemented with named regression cases; final-version native acceptance remains pending.

Source: the named project tests, the 19 October Windows baseline log/XML and recorded classifier evaluation. Later implementation changes retain separate acceptance status; subset counts are reported separately.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 38. 4.2.1 Implemented workflow and scope

**Before**: [New content]

**After**: Current-version additions comprise numbered tile inspection and original-crop preview, Square and resize guidance, Clear view and zero-row history selection, synchronised history input previews, stable linked navigation, clearer built-in/local model state, task-specific progress, background PDF generation and selectable report image quality. Ordinary Run now reads current preferences independently of restored or rerun records. These implemented additions are separate from the earlier Windows baseline and require final-version native acceptance.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 39. 4.2.2 Classification results and spatial inspection

**Before**: Figure 4.2 is a current Qt result-view capture using a deterministic synthetic fixture. It demonstrates the grid, paired views and statistics placement. The fixture deliberately contains 49 tiles with 47 STR, one NORM and one MUC assignments. These assignments are prescribed test data, not model predictions on the coloured source pattern and not evidence of classifier accuracy.

Figure 4.2. Tiled classification interface with source/result comparison and revised result toggles. Source: author’s Linux/offscreen-Qt development capture; synthetic fixture, not a model result.

**After**: In the current viewer, optional tile numbers identify the same one-based entry in the image, detail table and original-crop preview. The input summary displays the current Run dimensions and planned grid. Restoring an older result preserves its recorded geometry in the result panel while leaving current new-run preferences intact.

Figure 4.2 is a retained earlier Qt result-view capture using a deterministic synthetic fixture. It illustrates the grid, paired views and statistics placement. The fixture contains 49 tiles with 47 STR, one NORM and one MUC assignments. These are prescribed test data, not predictions on the coloured source pattern. Current-version real-image inspection remains reserved in Figure 4.3, including tile numbers and original-crop detail.

Figure 4.2. Tiled classification interface with source/result comparison and revised result toggles. Source: author’s Qt-simulated development capture; synthetic fixture, not a model result.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 40. 4.2.4 History, rerun and export

**Before**: [New content]

**After**: The current export implementation adds a background worker, cancellation and atomic replacement of completed PDF files. Standard and Original resolution settings distinguish sharing copies from full-pixel inspection. A controlled 2100 × 1500 synthetic texture/label fixture produced a classification report of 652,957 bytes in Standard versus 18,668,531 bytes at Original resolution, and a segmentation report of 652,071 versus 18,747,945 bytes. These measurements describe synthetic export fixtures, not model accuracy, a native Windows benchmark or a guaranteed Google Drive preview limit.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 41. 4.2.5 Settings, cancellation and interface polish

**Before**: Figure 4.7. Implemented Guide & Support page with persistent Contents navigation and numbered guidance. Source: author’s Linux/offscreen-Qt development capture; this is interface evidence.

**After**: The preference-lifetime regression defines a record at 8 × 7 source pixels, changes preferences to 16 × 12, restores or reruns the old record and starts a new run. For a 31 × 23 synthetic raster, its assertions require four real rectangles, including smaller right/bottom edges, while recorded rerun must retain its original geometry and backend. These small dimensions define deterministic test inputs and do not recommend a biological tile scale.

Figure 4.7. Implemented Guide & Support page with persistent Contents navigation and numbered guidance. Source: author’s Qt-simulated development capture; this is interface evidence.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 42. 4.2.5 Settings, cancellation and interface polish

**Before**: Figure 4.8. English history-calendar popup with a simulated Chinese default locale. Source: author’s Linux/offscreen-Qt development capture; the selected date is test input.

**After**: Figure 4.8. English history-calendar popup with a simulated Chinese default locale. Source: author’s Qt-simulated development capture; the selected date is test input.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 43. 4.2.6 Classification training and test results / table 16 row 10

**Before**: [New content]

**After**: Original checkpoint size | 1,726,089 bytes (1.646 MiB) | Measured genuine classification checkpoint; no model conversion performed

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 44. 4.3.1 Recorded automated results

**Before**: The final Windows invocation on 19 October 2026 completed the entire 370-test suite with 370 passed, 0 failed, 0 errors and 0 skipped, with 15 warnings in 194.10 seconds (exit 0). It used the native windows Qt platform, Python 3.10.22, PyQt5 5.15.11 and Qt 5.15.2. The evaluated source content is recorded in revision 7bd3552, as identified in Appendix C. Table 4.3 summarises this completed target-platform invocation.

Table 4.3. Final Windows automated test result

**After**: The completed Windows invocation on 19 October 2026 passed all 370 cases at baseline source 7bd3552, with 0 failures, 0 errors and 0 skipped cases, 15 warnings and 194.10 seconds (exit 0). Table 4.3 reports this dated baseline; its result is not extended to subsequent changes in revision 8c4830c.

Table 4.3. Completed Windows automated execution with its source version. Source: the recorded Windows log, XML result and exit status.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 45. 4.3.1 Recorded automated results / table 18 row 2; 4.3.1 Recorded automated results

**Before**: Windows, 19 Oct; final full run | 370 | 0 | 0 | 0 skipped; 15 warnings; 194.10 s; exit 0. Source revision 7bd3552.

Source: the full-suite pytest log and XML result of 19 October 2026, beginning at 22:26 (UTC+08:00). Appendix C provides the software version and earlier execution records.

The suite ran without test-case selection and completed with no skipped tests. Its 15 warnings concern deprecated Matplotlib/Pyparsing, PyTorch TypedStorage and Hugging Face download interfaces. The 194.10-second duration measures automated testing, not application inference performance.

**After**: Windows baseline, 19 Oct 2026 | 370 | 0 | 0 | 0 skipped; 15 warnings; 194.10 s; exit 0. Source revision 7bd3552.

Source: the complete Windows log/XML and exit record of 19 October 2026. Appendix C identifies its source version and preserves earlier Windows invocations separately.

The completed Windows invocation ran without test-case selection or skipped cases. Its duration measures automated testing, not inference latency. The separate 131-case Windows related subset is an independent execution and is not added to the 370-case complete-suite total.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 46. 4.3.1 Recorded automated results

**Before**: The final Windows suite passed the built-in-model availability assertion and the previously affected history, rerun, worker-lifetime and responsive-layout cases. The separate default-Pillow classifier evaluation in Section 4.2.6 supplies predictive measurements; passing software tests and file-availability checks do not measure segmentation accuracy.

**After**: The Windows baseline passed its built-in-model availability assertion and the history, rerun, worker-lifetime and layout cases in that source version. The separate classifier evaluation in Section 4.2.6 supplies predictive measurements. A file-availability check or a passing fixture does not measure segmentation accuracy.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 47. 4.3.2 Challenges, resolutions and evidence / table 20 row 14; 4.3.2 Challenges, resolutions and evidence / table 20 row 15; 4.3.2 Challenges, resolutions and evidence / table 20 row 16

**Before**: [New content]

**After**: Tile preference appeared to be ignored | History/re-run metadata remained in the input-panel cache; unchanged widget values emitted no refresh | Ordinary Run reads current preferences; only recorded Re-run supplies old parameters; finish/restore refresh the new-run summary | Named preference-lifetime cases assert actual crop boxes, current preference values and recorded geometry; final-version Windows acceptance remains pending.

PDF size and blocking export | Full image pixels embedded in small report panels; report generation was synchronous | Export-only display copies, Standard/Original resolution, task-preserving report metadata and cancellable atomic background generation | Named PDF encoding, data-preservation, layout and worker-lifecycle cases assert the implementation contract; current Windows acceptance and user report re-export remain pending.

Comparison drag/resize drift | Driver view was recentered during linked updates; viewport resize reused the wrong centre | Update the peer only, preserve source centre, proportional wheel zoom and rubber-band divider resizing | Named navigation, Fit and grid regression cases address coordinate stability; current native Windows manual acceptance remains pending.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 48. 4.3.3 Windows startup and window-state observations

**Before**: Native Windows automated checks now cover maximise/restore, saved-geometry recovery, repeated narrow/wide comparison, grid alignment and short viewports with accessible Run/Re-run actions. These completed checks resolve the earlier engineering regressions. Appendix D still reserves formal manual outcomes for authorised real-image workflows, real-model cancellation, screenshot verification and the intended display configurations.

**After**: The Windows baseline automated checks cover maximise/restore, saved geometry, comparison/grid alignment and compact action panels for that earlier source. Subsequent navigation, metadata wrapping, task-specific progress, model-source and tile-preference refinements require a new native Windows execution and formal manual records on the selected final version, as specified in Appendix D.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 49. 4.3.4 Runtime and deployment verification status

**Before**: The hardware and CPU runtime are documented in Table 4.4, but no repeated stage-level measurements were recorded for loading, preprocessing, forward inference, reconstruction/statistics, GUI display, saving or export. Cold and warm runs have not been separately summarised. Appendix E.3 defines the benchmark protocol; no measured latency, mean, standard deviation or throughput is filled in here.

The demonstrated delivery route is source execution in a Windows virtual environment. No PyInstaller build log, version-matched packaged artifact, clean-machine acceptance record or offline execution record was available. Standalone executable and fully offline deployment verification remain future work, separate from successful source startup.

**After**: The Windows hardware and CPU runtime are documented in Table 4.4. No repeated inference-stage or memory benchmark has been supplied, so model loading, preprocessing, forward inference, reconstruction/statistics, GUI display, saving and export retain unmeasured status. Appendix E.3 now specifies workload IDs, cold/warm boundaries, repetition counts, raw-record fields and summary rules. Existing export fixture file sizes are a separate file-size observation, not an inference-latency benchmark.

The demonstrated delivery route is source execution. The current repository contains a Windows PyInstaller specification, build script, genuine-resource preflight, bundled-configuration support and release-manifest generation. No corresponding completed build log, distributable artifact or clean-machine/offline acceptance was supplied. Tooling implementation is therefore reported separately from unverified deployment. No OpenVINO runtime or converted model is present.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 50. 4.5.1 Achievement of Research Objectives / table 24 row 2; 4.5.1 Achievement of Research Objectives / table 24 row 3; 4.5.1 Achievement of Research Objectives / table 24 row 4; 4.5.1 Achievement of Research Objectives / table 24 row 5; 4.5.1 Achievement of Research Objectives / table 24 row 6; 4.5.1 Achievement of Research Objectives / table 24 row 7; 4.5.1 Achievement of Research Objectives / table 24 row 8

**Before**: O1: local no-code workflow | PyQt5 application, background CPU work and cancel | Windows source startup and complete 370-test suite passed; clean offline executable remains unverified.

O2: model loading/validation | Supported formats, metadata reconstruction and probe checks | Windows real-classifier loading/validation and automated loader/path cases passed; semantic safety of arbitrary models is not established.

O3: inference tasks | Whole-image/tiled classification and segmentation | Default-Pillow Single image core: 90.68% accuracy / 88.59% macro-F1 on 7,180 native 224 × 224 patches. Segmentation and tiled predictive evaluation pending.

O4: result inspection | Charts, overlays, legends, spatial detail and linked comparison | Native Windows chart, legend, coordinate/grid and comparison regressions passed; formal real-image inspection tasks and UAT pending.

O5: export | PNG/PDF with task-specific metadata/artifacts | Native Windows temporary-artifact/report cases passed; real-image export demonstration pending.

O6: persistent records | SQLite and saved analysis/presentation artifacts | Native Windows persistence/artifact regressions passed; immutable per-run identities and backup not implemented.

O7: retrieval/rerun | Search, local-date filter, restore and recorded rerun | Native Windows search, calendar, restore and recorded-parameter rerun cases passed; efficiency awaits UAT.

**After**: O1: local no-code workflow | PyQt5 application, background CPU work and cancel | Local PyTorch CPU workflow implemented. Windows baseline startup and 370-test suite recorded. Current-version native acceptance and clean-machine offline delivery remain unverified.

O2: model loading/validation | Supported formats, metadata reconstruction and probe checks | Supported loader and task-default checks implemented. Real classifier loading recorded on Windows; structural probes do not establish unrestricted semantic compatibility.

O3: inference tasks | Whole-image/tiled classification and segmentation | Default-Pillow Single image core: 90.68% accuracy / 88.59% macro-F1 on 7,180 native patches. Crop coordinates and parameter isolation have explicit regression assertions; tiled predictive and segmentation evaluation remain pending.

O4: result inspection | Charts, overlays, legends, spatial detail and linked comparison | Numbered-tile inspection, original-crop detail, coordinate/grid and linked navigation are implemented with named regression cases. Final-version native real-image tasks and UAT remain pending.

O5: export | PNG/PDF with task-specific metadata/artifacts | Background atomic/cancellable PDF and two image-quality modes are implemented with named file/encoding/metadata cases. Synthetic size observations are separate from native acceptance; real-image export capture remains pending.

O6: persistent records | SQLite and saved analysis/presentation artifacts | SQLite/artifact persistence is recorded in the Windows baseline; clear-view history/source preservation is implemented. Per-run immutable file identities, backup and recovery are not implemented.

O7: retrieval/rerun | Search, local-date filter, restore and recorded rerun | Search, filtering, zero-selection, restore and recorded rerun are implemented. New-run preferences and saved-record parameters have separate lifetimes; user efficiency remains unmeasured.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 51. 4.5.1 Achievement of Research Objectives

**Before**: The implementation makes previously implicit choices visible: Single image versus Tiled analysis, source crop size versus network input, named resize backends, and tile-class coverage versus pixel coverage. The Windows patch evaluation supplies a measured default-path classifier result, and the 370-test native Windows run verifies the implemented software contracts under the documented test conditions.

**After**: The implementation makes task/mode, source crop versus network input, resize backend and coverage semantics visible. Current refinements strengthen numbered inspection, navigation, export and the separation of new-run preferences from recorded rerun settings. The patch evaluation supplies a measured classifier result; the completed Windows baseline supplies version-specific software verification.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 52. 4.5.3 Limitations and Constraints

**Before**: The complete 370-test native Windows suite provides automated regression evidence for the evaluated source state. Formal manual task acceptance and UAT remain incomplete, including authorised real-image screenshots, representative display configurations and real-model workflow observations. Assistive-technology testing and coverage measurement have not been completed. These activities address usability and deployment conditions beyond the controlled software cases.

Runtime and deployment require further measurement. The documented Windows execution is CPU-based; its installed RTX 4060 was not used. Repeated cold/warm stage timings, memory measurements, PyInstaller build records, clean-machine acceptance and offline dependency checks are unavailable, so the current delivery level is source execution.

**After**: The completed 370-test native Windows suite supports the earlier baseline. Later controls and workflows require final-version native Windows manual acceptance. UAT, authorised current screenshots and representative display/assistive-technology acceptance remain incomplete.

Runtime and deployment require further measurement. The recorded Windows execution uses PyTorch CPU, not its installed RTX 4060 GPU or an OpenVINO runtime. A fixed cold/warm benchmark protocol is prepared, but repeated timing and memory results remain unavailable. Windows build tooling is implemented; an actual version-matched package, clean-machine acceptance and offline execution are unverified. The demonstrated delivery remains source execution.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 53. 4.5.4 Implications for Future Development

**Before**: The immediate priorities are to complete formal real-image Windows acceptance, collect UAT responses and retain the passing regression suite as the baseline for further changes. The default application patch evaluation is complete; further model work should examine patient-grouped internal validation, different source dimensions and physical scale. Segmentation evaluation requires authorised aligned masks.

**After**: The immediate priorities are to resolve genuine resources on the chosen acceptance installation, run the current complete Windows suite, complete authorised real-image manual tasks and execute the frozen UAT protocol. The documented patch evaluation remains the classifier result; larger-crop and tiled predictive work requires its own authorised ground-truth design. No new biological generalisation result is introduced by the current software refinements.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 54. 4.6 Summary

**Before**: ZY-Path implements model-aware inference, spatial inspection and record continuity. The Windows default-Pillow Single image core reproduces 90.68% accuracy and 88.59% macro-F1 on 7,180 labelled patches. The final native Windows full suite completed with 370 passed, 0 failed, 0 errors and 0 skipped. UAT and the model, performance and deployment limitations remain as specified in Section 4.5.3.

**After**: ZY-Path implements model-aware inference, spatial inspection and record continuity, with current refinements to numbered tiles, preferences, reset operations and background report export. The default-Pillow Single image core achieves 90.68% accuracy and 88.59% macro-F1 on the documented native-sized patch test. The Windows baseline passed 370 cases. The remaining user, manual, performance and deployment evidence is specified in Section 4.5.3.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 55. 5.1 Conclusion

**Before**: The implementation adds explicit single-image and tiled classification, separate segmentation semantics, linked source/result inspection, task-specific model defaults and cooperative cancellation. In particular, tiled analysis retains actual crop coordinates and areas, exposes its sampling settings and labels coverage as an estimate. History and rerun preserve the recorded task/model/mode instead of silently applying current preferences. These details connect interface behaviour to the meaning of the numerical result.

The Windows application-default Pillow evaluation produced 6,511 correct predictions from 7,180 native-sized test patches, or 90.68% accuracy and 88.59% macro-F1. It matches the original OpenCV/Albumentations evaluation on every predicted label, while probabilities show small numerical differences. Separately, all 370 native Windows software tests passed without errors or skips, supporting the implemented loading, inspection, persistence, rerun, cancellation and export contracts. Formal manual acceptance and predictive generalisation retain the limits in Section 4.5.3.

**After**: The implementation adds explicit single-image and tiled classification, independent segmentation presentation, numbered crop inspection, linked original/result navigation, task-specific defaults, cooperative cancellation and background PDF export with two quality settings. Ordinary Run reads current preferences, while recorded rerun restores its own snapshot. Clear view resets transient state without deleting history. These behaviours connect the interface to the meaning and provenance of each completed result.

The Windows default-Pillow evaluation produced 6,511 correct labels from 7,180 native-sized test patches: 90.68% accuracy and 88.59% macro-F1. Every predicted label agrees with the recorded reference pipeline, with small probability differences. Software verification remains separate: the earlier native Windows baseline passed 370 cases with no failures, errors or skipped cases. Final-version native acceptance, UAT and broader predictive claims retain the limits in Section 4.5.3.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 56. 5.2 Future Work and Recommendations

**Before**: Further evaluation should examine patient- or slide-grouped internal validation, additional external cohorts, source-scale sensitivity, resize behaviour beyond native-sized patches and segmentation against authorised masks. Formal real-image Windows acceptance should complement the completed automated suite, which provides the regression baseline for subsequent development.

**After**: Further evaluation should examine patient- or slide-grouped internal validation, additional authorised cohorts and larger-crop/tiled predictive behaviour under documented source geometry. The immediate engineering follow-up is current-version Windows regression and manual acceptance, followed by the predefined timing/memory protocol. Passing subsets must not replace the full-suite result, and unavailable resources must remain reported rather than substituted.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 57. 5.2 Future Work and Recommendations

**Before**: The third priority is reproducibility and deployment. Add file checksums, dependency manifests and versioned metadata to saved records; define artifact transaction/recovery behaviour and backups; package the application with all permitted resources; and test it on a Windows machine without the development environment. Security and model-licensing review should accompany distribution, especially where serialized model objects remain supported.

**After**: The third priority is reproducibility and deployment. Complete version-matched Windows build and clean-machine/offline acceptance using the implemented tooling; retain required resource permissions. Per-run file checksums, dependency manifests, versioned metadata, artifact recovery and backups remain further work. An export-time checksum identifies the currently accessible file and does not establish which immutable weight file produced an older record.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 58. 5.3 Research Contributions

**Before**: The third contribution is a tested approach to inspection and state continuity: shared coordinate transforms, linked views, vector tile boundaries, responsive layouts, recorded rerun settings and safe cancellation preserve meaning across user actions. The regression cases document defects that purely static or offscreen screenshots had not been sufficient to assess.

**After**: The third contribution is an implementation approach to inspection and state continuity: shared coordinate transforms, linked views, vector tile boundaries, responsive layouts, recorded rerun settings and safe cancellation preserve meaning across user actions. The named regression cases document defects that static screenshots alone had not been sufficient to assess.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 59. 5.4 Summary

**Before**: ZY-Path implements the central CP1 workflow and extends it with explicit spatial analysis and stronger state management. The measured classifier result and the completed 370-test native Windows suite complement source-startup observations. UAT, formal manual acceptance, segmentation evaluation and verified packaging are the next steps toward stronger usability, generalisation and deployment claims.

**After**: ZY-Path implements the central CP1 workflow and extends it with explicit spatial analysis, numbered inspection and stronger state/export management. The measured classifier result and dated Windows automated record support different aspects of the work. Current-version Windows manual acceptance, UAT, systematic runtime/memory measurements and clean-machine deployment remain unfinished and must be completed or retained as explicit limits.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 60. A.2 Implementation and outstanding milestones / table 27 row 2

**Before**: Core interface/inference/persistence integration | Project modules and completed 370-test native Windows run | Implemented under supported contracts

**After**: Core interface/inference/persistence integration | Current revision 8c4830c; completed Windows baseline 7bd3552 recorded separately | Implemented under supported contracts

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 61. A.2 Implementation and outstanding milestones / table 27 row 9; A.2 Implementation and outstanding milestones / table 27 row 10

**Before**: Formal UAT and Windows acceptance record | Windows automated regressions complete; source startup recorded; no UAT responses or completed manual task sheets | Automated Windows verification complete; formal manual acceptance and UAT pending

Clean-machine packaged distribution | No verified executable/specification supplied | Pending

**After**: Formal UAT and Windows acceptance record | Versioned task/material protocol prepared; Windows baseline recorded; no actual UAT responses or completed final-version manual sheets | Automated Windows verification complete; formal manual acceptance and UAT pending

Clean-machine packaged distribution | Build script/specification and resource preflight implemented; no verified package or clean-machine run | Build preparation implemented; deployment verification pending

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 62. A.2 Implementation and outstanding milestones / table 27 row 12

**Before**: [New content]

**After**: Current-source regression and refinements | Revision 8c4830c; current export, navigation and preference implementation with named regression cases | Implemented; current-version native Windows execution and manual acceptance remain pending

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 63. A.3 Completion sequence

**Before**: Before submission, complete authorised GUI screenshots, formal manual acceptance, UAT and the remaining cover fields. Retain the completed 370-test Windows result and the default-Pillow patch evaluation with their actual source and dataset scope. Final formatting and clean-machine packaging claims follow their corresponding review and execution evidence.

**After**: Before submission, select and record the final software source, collect its native Windows result, complete authorised screenshots/manual tasks and the frozen UAT protocol, and supply semester/submission date. Preserve the earlier Windows baseline and classifier evaluation with their real scope. Execute the performance or deployment protocols only when those claims are to be made; otherwise retain their explicit incomplete status.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 64. B.1 Participant information and consent briefing

**Before**: [New content]

**After**: Before recruitment, record the institution’s actual approval or exemption requirement and its reference if applicable; no approval is claimed here. Explain the permitted recording, quotation and withdrawal arrangements, access-limited storage and disposal under the applicable assessment/appeal and institutional retention rules. The exact approved storage/retention arrangements remain fields to complete in the study register, rather than an invented ethics clearance.

**Reason**: Define prospective study materials and observable task outcomes without inventing participants or responses.

## 65. B.3 Standard task script and observation rules / table 28 row 2; B.3 Standard task script and observation rules / table 28 row 3; B.3 Standard task script and observation rules / table 28 row 4; B.3 Standard task script and observation rules / table 28 row 5; B.3 Standard task script and observation rules / table 28 row 6; B.3 Standard task script and observation rules / table 28 row 7; B.3 Standard task script and observation rules / table 28 row 8; B.3 Standard task script and observation rules / table 28 row 9; B.3 Standard task script and observation rules / table 28 row 10; B.3 Standard task script and observation rules / table 28 row 11

**Before**: T01 | Load the supplied image and run Single image with the approved model | Correct image/model/mode and completed output identified without coding

T02 | Select Tiled analysis, set the specified source width/height and run | Correct explicit mode and source dimensions are used

T03 | Find a tile's class/confidence and explain coverage | Identifies actual tile detail; states coverage is a crop-class area estimate, not pixel ground truth

T04 | Compare a selected region with the original and use Fit/zoom | Same source region remains aligned; participant can return to Fit

T05 | Inspect the supplied segmentation result | Distinguishes segmentation labels and pixel coverage from classification tiles

T06 | Search/date-filter history and restore the nominated record | Correct stored record shown without initiating inference

T07 | Change a current preference, then rerun the stored record | Recorded model/mode/parameters used; new record distinguished from restored one

T08 | Export the nominated completed result | Correct PNG/PDF and actual task/model metadata identified

T09 | Start the supplied workload and cancel it | Recognises request/acknowledgement; no partial completed record saved

T10 | Save a supplied validated default and restore the built-in default | Correct task's preference changes; other task/history remain unaffected

**After**: T01 | Load approved P01 and run Single image with classification model M01 | Correct P01/M01/mode and completed output identified; no coding

T02 | Load approved P02 (1024 × 768), choose Tiled analysis and set 256 × 256 using Square | Recorded source geometry 256 × 256, Pillow bilinear, 12 tiles (4 columns × 3 rows); no claim of an optimal scale

T03 | Show tile numbers, select tile #6 and explain its class/confidence and coverage | Tile #6 rectangle [256, 256, 512, 512]; image/table/crop agree; explains model score and tile-class estimate

T04 | Compare the tile-6 region with the original, pan/zoom linked views, then return to Fit | Corresponding region remains aligned; participant returns to Fit without resetting preferences

T05 | Open the prepared real-model segmentation result S01; inspect overlay/map and coverage | Distinguishes segmentation’s own labels and pixel coverage from classification estimates; no diagnostic correctness task

T06 | Find and restore prepared tiled record R01 using the assigned keyword/date | Correct R01 shown with its saved result/parameters; no inference or new record

T07 | Set current dimensions to 512 × 512, Re-run R01, then start ordinary Run Inference | Re-run retains 256 × 256 and 12 tiles; ordinary Run uses current 512 × 512 and 4 tiles; records are distinguished

T08 | Export the nominated completed record as Standard PDF and PNG; identify its metadata | Correct files/record identity/statistics; PDF quality identified and source dimensions retained

T09 | Start approved workload C01 and request cancellation; inspect the completed history | Request and acknowledgement recognised; no partial completed record; previous completed results retained

T10 | Set validated real classification model M01 as that task’s default, then restore built-in | Classification default changes/restores; segmentation default and old records remain unchanged

**Reason**: Define prospective study materials and observable task outcomes without inventing participants or responses.

## 66. B.3 Standard task script and observation rules

**Before**: For each attempted task record start/end or elapsed seconds, outcome (independent success, assisted success, unsuccessful, not attempted), assistance count, critical error and a brief observation. Define a stop rule consistently before testing. An intended cancellation is successful when safe acknowledgement and record preservation occur, not when the model stops instantly. If a prepared file is unavailable, record an environment-blocked attempt rather than blaming the participant or silently substituting another task.

**After**: Protocol 1.0 uses a 180-second task limit from the end of the instruction, except T08 export and T09 cancellation, which allow 300 seconds. Observer timing separates user-action time from application waiting where possible. At the limit, record Timeout; offer help only after that outcome is saved. Independent success requires no task-solving hint. Repeating an instruction verbatim is logged as clarification; a directional or procedural hint makes completion assisted. A critical error is an action that produces/exports the wrong nominated result, changes the wrong task default, deletes a required record, or confuses estimated coverage with pixel ground truth. Intended cancellation succeeds on acknowledgement and preservation of completed records. A missing material or crash is recorded as environment-blocked/system failure separately from participant inability. These predefined rules can be revised before the first participant, with a new protocol version, but not selected retrospectively to improve results.

**Reason**: Define prospective study materials and observable task outcomes without inventing participants or responses.

## 67. B.3 Standard task script and observation rules

**Before**: [New content]

**After**: The material register maps P01/P02/S01/R01/C01/M01 to actual filenames, checksums, permissions and source/record identifiers. Its current blank source fields mean the pack is not yet authorised for execution. Before each session, restore the same prepared application profile and records; retain the participant’s anonymous ID and software revision. A five-minute orientation uses a separate practice example. T01–T10 keep a fixed order for comparability, so results will acknowledge possible learning/fatigue effects rather than claim a counterbalanced experiment.

**Reason**: Define prospective study materials and observable task outcomes without inventing participants or responses.

## 68. C.1 Source baseline

**Before**: The evaluated application source is recorded in commit 7bd3552765af9d318a02bccd3e2469b95155dbe3, tagged cp2-windows-verified-2026-10-19. The commit was created on 20 October 2026 from the source content exercised by the completed Windows tests on 19 October; the repaired files match the recorded Windows source after line-ending normalisation. The original logs retain the pre-commit identifier 1f3e01e7866d1b1f78103d817214f7dbb1cc5a56. Table C.1 lists the evaluation materials, and Table C.2 gives the execution history.

**After**: The current application source is commit 8c4830c1281e4a85248c9a2ea9d0adae64bd4525. The completed Windows baseline is 7bd3552765af9d318a02bccd3e2469b95155dbe3, tagged cp2-windows-verified-2026-10-19, recorded after the 19 October Windows run. Original Windows logs retain their original identifiers. Table C.1 identifies the supporting materials and Table C.2 separates the actual Windows executions.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 69. C.1 Source baseline / table 29 row 21; C.1 Source baseline / table 29 row 22; C.1 Source baseline

**Before**: Source: project modules, experiment files and identified test records listed in the table.

**After**: E20 | Current data/pdf_report.py; ui/pdf_export_worker.py; PDF layout/quality and worker tests | Background atomic export, recorded metadata, exact palette preservation and Standard/Original resolution fixture sizes

E21 | Current test_tile_preferences_lifetime.py | Named preference-lifetime regression source asserts current-run dimensions, recorded rerun parameters, crop boxes, history metadata and active-run snapshot isolation.

Source: application code, experiment files and dated test records.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 70. C.2 Evidence interpretation

**Before**: Table C.2 distinguishes the completed native Windows run from earlier Windows collection and runtime interruptions. The final invocation completed 370 tests with no failures, errors or skips. A preceding 131-test regression subset passed in 119.90 seconds with 15 warnings; its count is not added to the full-suite total. Classifier performance is reported separately in Section 4.2.6.

Table C.2. Windows automated test execution history

**After**: Table C.2 separates the completed Windows baseline from earlier Windows interruptions. The baseline has 370 passes; the 131-case related subset is an independent record and is not added to the complete-suite total. No later source version is assigned that earlier outcome.

Table C.2. Windows automated execution history.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 71. C.2 Evidence interpretation

**Before**: Source: Windows pytest logs, XML results and exit codes of 19 October 2026. “Not final” and “Not run” identify incomplete invocations rather than passing-test totals.

**After**: Source: Windows log/XML and exit records of 19 October 2026. Incomplete invocations retain their recorded status.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 72. D.1 Native acceptance record

**Before**: For each manual acceptance case record date, tester, source state, Windows/Python/dependency versions, hardware, Qt display metrics, model/input identity, expected outcome, actual outcome and evidence file. The source-startup log gives partial manual observations, while the completed Windows suite supplies automated coverage for several corresponding behaviours. Table D.1 remains a manual acceptance checklist: its outcomes require the specified real-image task records and must not be filled from automated test totals alone.

**After**: For each manual acceptance case record date, tester, final source state, Windows/Python/dependency versions, hardware, actual Qt platform/display metrics, model/input identity, expected outcome, actual outcome and evidence file. The earlier source-startup record and baseline suite do not automatically accept current changes. Table D.1 remains a manual checklist: a Pass requires the specified observed native task record and is not inferred from an older Windows total.

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 73. D.1 Native acceptance record / table 31 row 14; D.1 Native acceptance record / table 31 row 15; D.1 Native acceptance record / table 31 row 16

**Before**: [New content]

**After**: W13 | Restore old tiles, edit preferences, Run; then use recorded Re-run | Current Run geometry/backend match Preferences; Re-run retains its record; ordinary Run after rerun again uses current preferences

W14 | Use tile numbers, image/table selection and Square; clear view/selection | IDs/boxes/crop preview agree; Square copies once; clear operations preserve saved history/source files

W15 | Export both PDF qualities; cancel an export; reopen the output | Quality and original dimensions are accurately labelled; numeric data agree; cancellation/failed export preserve the previous destination

**Reason**: Update current implementation details while reporting only the dated Windows execution and preserving uncollected evidence as pending.

## 74. E.3 Runtime and deployment

**Before**: Use the documented Windows CPU environment as a benchmark baseline, fixing source dimensions, model, classification mode, resize backend and tile settings. Time cold model loading separately from warm repeated runs; measure preprocessing, forward inference, reconstruction/statistics, GUI display, saving and export as distinct stages. Report repeat count, mean, sample standard deviation, median and range, with memory measurements where available. The recorded pytest durations are excluded from inference timing. Packaging verification additionally requires a matched PyInstaller build record and artifact revision, clean-machine task checks and an offline dependency test; these remain planned activities.

**After**: Benchmark protocol 1.0 fixes the application revision, genuine model checksum, Python/dependency versions, CPU/thread setting, source identity/dimensions, task, resize backend and tile/stride/input geometry. Use B01: native 224 × 224 classification; B02: 1024 × 768 classification with 256 × 256 source tiles (12 tiles); B03: 3552 × 3536 classification with 512 × 512 tiles (49 tiles); and B04: one authorised segmentation raster whose dimensions and independent geometry are entered before measurement. Material identifiers are protocol definitions; their actual file assignments remain pending. Keep model loading separate from already-loaded inference, and record full workload metadata for every attempt.

Perform five fresh-process cold-load repetitions per model and ten warm repetitions per workload after one explicitly excluded warm-up. Define boundaries with a monotonic clock: load/validation; preprocessing; forward work; reconstruction/statistics; GUI-ready display; artifact/database save; and PDF export. Where instrumentation cannot isolate a stage, mark that stage Not measured and report the available end-to-end interval instead of estimating it by subtraction. Record all attempts, failures and cancellations; do not replace slow observations selectively. Summarise valid repetitions with n, mean, sample standard deviation, median and range. Record process baseline/peak RSS where tooling is available and state its sampling interval and definition.

For report-size checks, export the same completed result in both PDF qualities with identical appendix/path settings. Record file bytes and generation duration separately from inference, and verify selected numeric rows, labels and image aspect ratios. A successful local open is not an online-hosting preview guarantee. Packaging acceptance additionally records the build command/log, permitted resources, artifact checksum, clean Windows configuration, offline state and each task outcome. No new latency, packaged-release or clean-machine result is supplied in this revision.

**Reason**: Supply a repeatable performance/deployment protocol without presenting it as an executed result.

## 图示与局部布局

更新Figures 3.1、3.3–3.6的架构与UML图；保持原文献/样式/指标。类图采用紧凑纵向布局，附录表格来源行置于表后并检查分页。当前出版资料包不含会谈文件及不纳入展示的测试平台附件。
